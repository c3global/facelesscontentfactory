# Your first Faceless48 video

This private beta is for a computer with Claude Code or Codex and local file access.

1. Unzip the package into a folder outside cloud sync (not iCloud, Dropbox or OneDrive).
2. Open that folder in Claude Code or Codex.
3. Paste this:

> Read START-HERE.md and set me up.

That's it. Your assistant asks for permission, then installs and tests everything for you in one step: the video tools, the captions engine and the cutout tools. You don't install anything yourself and you don't need to type commands. The first run takes about 10 to 20 minutes (most of it is downloading); you can step away while it works. At the end it shows a short report. If an item says FIX, it tells you in plain words what to click, and running setup again picks up where it left off.

Then it walks you through your brand setup (30 to 60 minutes, once): your name, logo, colors, metallic finish, fonts, who appears in your videos (you, an AI avatar, a 2D or 3D character, or the stick figure) and your caption style, with previews. Everything is saved, so you only do this once.

**For the assistant:** ask the member where to keep their videos (suggest a "Faceless48 Videos" folder in their home folder, outside cloud sync), ask permission to install, then run `node tools/setup.mjs "<that folder>"` from this package folder and work in that project folder from then on. Read the report in `out/setup-report.txt` and walk the member through any FIX line in plain language. On a Mac, if the report asks for the Command Line Tools, tell the member to click Install in the window that opened, wait for it to finish, then run setup again. Never ask the member to type commands. When everything is ready, continue with skills/brand-setup/SKILL.md.

## What you can say once you are set up

| Say this | What happens |
| --- | --- |
| **Get me set up** | The one-time brand onboarding (30 to 60 minutes). Never needed again. |
| **Make my video** | Talking-head edit of your clip: captions, cutaways, effects, your style. Vertical by default. Say "make it horizontal for YouTube" for a 1920 x 1080 version. Shows stills first, then renders. |
| **Show me the storyboard** | The whole video as numbered frames, in order, with the words under each one. You approve it or name the frames to change before anything renders. Asked for automatically before every first render. |
| **Edit my yap** | Casual in-car or at-home video: captions, tightened pauses, a music bed, slow zooms, nothing more. Confirms the transcript with you first. |
| **Make a video carousel** | An animated 4:5 carousel, one idea per slide, in your brand, with you, your AI avatar or no one on the slides. Start from a template: say "use the tech, influencer or LinkedIn carousel template." |
| **Make a life scene** | Cinematic clips (Google Flow, Veo, Seedance, stock or your own) with a camera move and your on-screen text. |
| **Turn my voiceover into an explainer** | Animated explainer in portrait or landscape. |
| **Find stock footage for this** | Optional Pexels and Pixabay search with your own free keys. |
| **Add my music** | Puts your licensed track under a finished video and ducks it under the voice. |

## Which model should I use?

Any model works. Every effect is built in, so it looks the same whichever model you use. A stronger model picks effects and places them on your words more creatively; a lighter one is faster and uses fewer credits. Either way, you approve the storyboard before anything renders.

## Using it with GPT (Codex) instead of Claude

The same package works in Codex because the instructions are plain files. Use Codex on your own computer (the desktop app or the terminal), not the browser chat.
1. Unzip the package and open that folder in Codex.
2. Paste the same first message as above. Codex reads `AGENTS.md` in this folder, which points it to the skills.
3. Everything else is identical: the commands in the table work as written.
Both Claude Code and Codex need Node 20.6 or newer (from nodejs.org); setup installs everything else. The package works in both Claude Code and Codex. If anything behaves differently, send the exact message and error text.

## Getting your footage to the assistant

Chat attachments have size limits, and most talking-head clips are bigger than that. Use one of these instead.

**Best: put the file inside your project folder.** If your assistant runs on your own computer (Claude Code desktop or terminal, or Codex on your computer), copy the video into your project's `public/raw/` folder and tell the assistant the file name. Nothing has to be uploaded.

**If your assistant runs in the cloud** (Claude Code on the web, a Codex cloud task, or a session started from your phone), it cannot see your computer's files. Host the video in a cloud folder:

1. Upload the video to Google Drive, Dropbox or OneDrive.
2. Set sharing to "Anyone with the link can view."
3. Paste the link into the chat and say: "Download this video into my project and edit it."
4. After the edit is done, set sharing back to Restricted.

If the assistant has a Google Drive connector, it can find the file by name, but it can usually download large videos only when they are shared by link.

Cloud sessions also need permission to reach the file host. If the download is blocked, add these to the environment's allowed network domains: `drive.google.com` and `drive.usercontent.google.com` (Google Drive), `dropbox.com` and `dl.dropboxusercontent.com` (Dropbox). Setup downloads the captions and cutout models once from `huggingface.co`, so allow that too.

Keep clips under about 2 minutes for the first tests. A 30 to 60 second clip is ideal.

After setup, choose one:

> Edit my supplied talking-head video. Use my brand colors, meaningful full-screen cutaways and readable captions. Show me a preview before the full export.

> Turn my voiceover into an animated explainer. Choose layouts that teach the ideas, use the neutral character for now, and match the visuals to the spoken words. Handle the plan file for me.

You provide your footage or voiceover. The assistant handles the project and plan. Use your own licensed character art/music if desired. See README.md for optional native plugin loading. This beta has local rendering proofs, but setup on other machines is still being tested.

For feedback, record the assistant/version, operating system, what you asked, and the exact error or problem. Never include passwords or API keys.

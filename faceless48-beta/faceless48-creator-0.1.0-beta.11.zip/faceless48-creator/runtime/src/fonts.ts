import customerBrand from "./brandConfig";
import {continueRender, delayRender, staticFile} from 'remotion';
import {loadFont as loadDMSans} from '@remotion/google-fonts/DMSans';
import {loadFont as loadMontserrat} from '@remotion/google-fonts/Montserrat';
import {loadFont as loadPlayfair} from '@remotion/google-fonts/PlayfairDisplay';
import {loadFont as loadAnton} from '@remotion/google-fonts/Anton';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';
import {loadFont as loadCovered} from '@remotion/google-fonts/CoveredByYourGrace';
import {loadFont as loadSwanky} from '@remotion/google-fonts/SwankyandMooMoo';
import {loadFont as loadRubik} from '@remotion/google-fonts/Rubik';
import {loadFont as loadBagel} from '@remotion/google-fonts/BagelFatOne';
import type {SansOption} from './brand';

declare const process: {env: Record<string, string | undefined>};

export const serifFamily = `"${customerBrand.headingFont}", Georgia, serif`;
export const handFamily = '"Caveat", "Bradley Hand", cursive';
/** handwritten faces for Life Scene text cards */
export const handFamilies = {
  covered: '"Covered By Your Grace", cursive',
  caveat: '"Caveat", cursive',
  swanky: '"Swanky and Moo Moo", cursive',
} as const;
/** a round, very heavy face for the bubble (liquid glass) letters */
export const bubbleFamily = '"Bagel Fat One", "Rubik", "Arial Rounded MT Bold", sans-serif';
export const heavyFamily = '"Anton", "Impact", "Arial Narrow", sans-serif';
export const sansFamily = (sans: SansOption) => `"${customerBrand.bodyFont || sans}", "Helvetica Neue", Arial, sans-serif`;

/**
 * Fonts load through @remotion/google-fonts. If Google Fonts is unreachable (for example a
 * locked-down render sandbox), set REMOTION_LOCAL_FONTS=1 to load the bundled copies in
 * public/fonts instead. Same families, same weights.
 */
const localFaces: Array<[string, string, string, string]> = [
  ['DM Sans', 'dm-sans-latin-500-normal.woff2', '500', 'normal'],
  ['DM Sans', 'dm-sans-latin-700-normal.woff2', '700', 'normal'],
  ['Montserrat', 'montserrat-latin-500-normal.woff2', '500', 'normal'],
  ['Montserrat', 'montserrat-latin-700-normal.woff2', '700', 'normal'],
  ['Playfair Display', 'playfair-display-latin-400-normal.woff2', '400', 'normal'],
  ['Playfair Display', 'playfair-display-latin-600-normal.woff2', '600', 'normal'],
  ['Playfair Display', 'playfair-display-latin-700-normal.woff2', '700', 'normal'],
  ['Playfair Display', 'playfair-display-latin-400-italic.woff2', '400', 'italic'],
  ['Playfair Display', 'playfair-display-latin-600-italic.woff2', '600', 'italic'],
  ['Playfair Display', 'playfair-display-latin-700-italic.woff2', '700', 'italic'],
  ['Playfair Display', 'playfair-display-latin-800-normal.woff2', '800', 'normal'],
  ['Playfair Display', 'playfair-display-latin-800-italic.woff2', '800', 'italic'],
  ['Playfair Display', 'playfair-display-latin-900-normal.woff2', '900', 'normal'],
  ['Playfair Display', 'playfair-display-latin-900-italic.woff2', '900', 'italic'],
  ['Anton', 'anton-latin-400-normal.woff2', '400', 'normal'],
  ['Caveat', 'caveat-latin-700-normal.woff2', '700', 'normal'],
  ['Caveat', 'caveat-latin-600-normal.woff2', '600', 'normal'],
  ['Covered By Your Grace', 'covered-by-your-grace-latin-400-normal.woff2', '400', 'normal'],
  ['Swanky and Moo Moo', 'swanky-and-moo-moo-latin-400-normal.woff2', '400', 'normal'],
  ['Rubik', 'rubik-latin-900-normal.woff2', '900', 'normal'],
  ['Bagel Fat One', 'bagel-fat-one-latin-400-normal.woff2', '400', 'normal'],
];

let started = false;

export const loadBrandFonts = () => {
  if (started) return;
  started = true;

  if (process.env.REMOTION_LOCAL_FONTS === '1') {
    const handle = delayRender('Loading bundled brand fonts');
    Promise.all(
      localFaces.map(([family, file, weight, style]) =>
        new FontFace(family, `url(${staticFile(`fonts/${file}`)})`, {weight, style})
          .load()
          .then((face) => document.fonts.add(face)),
      ),
    )
      .then(() => continueRender(handle))
      .catch((err) => {
        console.error(err);
        continueRender(handle);
      });
    return;
  }

  loadDMSans('normal', {weights: ['500', '700'], subsets: ['latin']});
  loadMontserrat('normal', {weights: ['500', '700'], subsets: ['latin']});
  loadPlayfair('normal', {weights: ['400', '600', '700', '800', '900'], subsets: ['latin']});
  loadPlayfair('italic', {weights: ['400', '600', '700', '800', '900'], subsets: ['latin']});
  loadAnton('normal', {weights: ['400'], subsets: ['latin']});
  loadCaveat('normal', {weights: ['600', '700'], subsets: ['latin']});
  loadCovered('normal', {weights: ['400'], subsets: ['latin']});
  loadSwanky('normal', {weights: ['400'], subsets: ['latin']});
  loadRubik('normal', {weights: ['900'], subsets: ['latin']});
  loadBagel('normal', {weights: ['400'], subsets: ['latin']});
};

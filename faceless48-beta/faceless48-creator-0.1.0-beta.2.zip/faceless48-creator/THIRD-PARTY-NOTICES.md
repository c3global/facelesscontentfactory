# Third-party notices

Remotion and npm dependencies retain their own licenses. This package does not grant a Remotion commercial license. Review the applicable terms at https://www.remotion.dev/license before commercial distribution/use. Dependencies are installed from the pinned package-lock.json and are not bundled as node_modules.

Bundled font licenses are in runtime/licenses/. The optional MediaPipe selfie segmentation model comes from the original source runtime; Google's model card identifies the model license as Apache 2.0: https://storage.googleapis.com/mediapipe-assets/Model%20Card%20MediaPipe%20Selfie%20Segmentation.pdf . The Apache license is included in runtime/licenses/mediapipe-APACHE-2.0.txt. Model authors: Tingbo Hou, Siargy Pisarchyk and Karthik Raveendran, Google.

No third-party music beds, personal host portraits or personal source videos are bundled. The sample video is a synthetic test fixture. The sample voice is a locally synthesized test fixture, not a production voice offering. Decorative SVG replacements are simple locally created shapes. Included sound effects came from the source project's generated-effects library.

Faceless48 source provenance and pinned revision are recorded in SOURCE.json. Commercial product terms and member entitlements are maintained by the owner; this beta does not invent a license policy or change an existing lifetime purchase.

# Faceless48 project

Before any video work, read `brand-profile.md` (the member's saved brand and preferences) and follow it.
If `brand-profile.md` does not exist, run the brand-setup skill first ("get me set up").
Video workflow: the plugin's `skills/video-production/SKILL.md`. Onboarding: `skills/brand-setup/SKILL.md`.

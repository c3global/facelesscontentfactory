# Editing rules (read before planning any talking-head edit)

These rules come from weeks of real edits and reviews. They are what makes a video feel finished instead of busy. Follow them unless the member asks for something different, and save any standing change they ask for in `brand-profile.md`.

## Cadence
- A visual change at least every 4 seconds, and on key words. Either cut away to show what the words mean, or stay on the person on purpose.
- The person stays full frame for about 4 seconds at a time, 6 at most. Picture-in-picture, split screen and hidden-person scenes all count as cuts.
- One strong effect every 4 to 6 seconds is plenty. Packed demos are not a model for real videos.
- Plan at least one diagram or list for any script that teaches a framework or steps, and a proof cutaway (a real source card or page capture the member supplies) for every cited source.

## Face and safe zones
- Never put a tag, pill or card on the face. Cards that sit in the top half of a full-frame shot cover the face: lists, charts and comment bubbles go in the lower third.
- Keep text clear of the top 12 percent, the bottom 22 percent and the right 12 percent of a portrait frame (platform buttons live there).
- Pill captions always sit at the bottom. In split-screen layout `S` the person fills the lower half, so pill captions land on the face. Use layout `C` or `E`, or editorial captions, for those moments.
- Do not stack two effects that both cover the lower third.
- Behind-person effects work best in full-frame layout `A`. They need a matte (`npm run matte -- <slug>`). Footage with a plain background and clear light between the person and the wall cuts out best; say so if the background touches their edges, and offer the outline dial.

## Captions
- Never drop a spoken word.
- When a graphic shows every word being said (statement card with word times, headline, chips), turn captions off for that segment (`"captions": "off"`) so nothing is read twice. If even one word is missing from the graphic, keep the captions.
- A caption chunk never ends on a connector word (and, the, of, to). The editorial chunker handles this; check it in stills.
- Captions stop where the end card starts.

## Pills and labels
- Each pill goes in the right place for what it labels, never over the face, never colliding with captions or another graphic.
- Pills stay on screen only long enough to read. No pill lingers for a whole scene.

## Timing
- Land effects on the words. Use the real word times from the transcript (`npm run word -- <slug> "phrase"` or the captions file), never guessed times. Guessed timing is the most common reason an edit feels off.

## Process
1. Transcribe, then show the member the transcript to confirm names, links and the closing line before building anything. Whisper splits names and sometimes invents words after the audio ends: delete words that start after the video ends.
2. Check the ending of the take. If it is cut off mid-sentence, say so before editing.
3. Show stills of every new look and effect moment before a full render. Once a look is approved, full renders of that look need no new approval.
4. Render one frame at a time (concurrency 1). Parallel rendering can paint random frames white. After rendering, scan for flashes: `ffmpeg -i out/<slug>.mp4 -vf signalstats -f null -` and look for YDIF spikes that are not at planned cuts.
5. Report what you checked and what you could not (an assistant cannot hear audio; the member's ear decides music and sound levels).

## Content
- Never invent facts, numbers, quotes, credentials, testimonials or client results. Card text comes from the member's script or supplied material. Flag gaps instead of filling them.
- Illustrative interface text (a chat message, a notification) must stay generic.
- Music sits well under the voice (about 17 dB below while speaking) with ducking. Use only music the member has the rights to.

## Proven-effects shortlist
- **Hook:** digital-zoom with a snap on the key word.
- **Contrast or myth:** headline-card with strikeAt on the word that rejects it.
- **The thesis line:** statement-card with word times, captions off, layout `E` or `C`.
- **A question the audience should ask:** prompt-bar.
- **Close or call to action:** type-wall behind the person (needs matte), or an end card.

## Cutouts (behind-person effects)
- The default cutout (`npm run matte`) is fast but can leak into a sofa or chair of a similar color, or wobble at the edges. Check it on a close crop of an effect moment before rendering.
- If the edge is not clean, use the high-quality cutout: `python3 scripts/matte-hq.py <slug> <startSec> <endSec>` (BiRefNet, MIT license). It needs a one-time 220 MB model download (see the top of that script; ask the member first) and takes about 18 seconds per frame on a CPU, so cut only the seconds an effect uses. A GPU is much faster.
- Do not hide a poor cutout with an outline. The outline follows the mask, so a bad mask makes a bad outline.

## Music
- Add the member's licensed track with `npm run f48 -- mix-music <video.mp4> <track.mp3> [out.mp4]`. It loops the track to length, ducks it under speech and fades in and out. Level the track first (about -24 LUFS), and use only music the member has the license for. An assistant cannot hear: the member approves the mix by ear.
- Explainers (stick plans) take a `music` block in the plan instead.

## Gradient and labels
- The dark gradient behind a full-frame hook caption starts low (56 percent of the frame height) and is light, so it never covers the torso.
- A style label (`tag`) and top-of-frame captions must never share the same seconds. Show the label while captions are at the bottom, then move captions up.

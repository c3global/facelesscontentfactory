# Faceless48 Creator (package instructions for Codex and other agents)

This folder is the Faceless48 Creator package. Do not edit it. Work in the member's own project folder.

- First time, or "get me set up": read `skills/brand-setup/SKILL.md` and `skills/video-production/SKILL.md`, then create a project with `node tools/create-project.mjs <new-project-folder>`.
- "Make my video", "edit this", "do ya thing": `skills/video-production/SKILL.md`.
- "Edit my yap": `skills/yap/SKILL.md`.
- "Make a life scene": `skills/life-scenes/SKILL.md`.
- Inside a project, `CLAUDE.md` and `AGENTS.md` repeat these rules and tell you to read `brand-profile.md` first.
- Run everything locally. Never post, schedule or publish. Never put API keys in chat.

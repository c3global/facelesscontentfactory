Current files and music assignments: [Updated reel review](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Clients/Faceless48 Demo/November Clinic Notes/November review.md>). The current review overrides earlier track and layout notes below.

Afternoon revision status and current export links: [November review](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Clients/Faceless48 Demo/November Clinic Notes/November review.md>). This queue preserves the approved Content OS copy; the review file governs current music and export choices.

# November 2026 Cinematic Clinic Notes

Eight approved Content OS rows, in Eastern publish-date order. The hook and tips below are the on-screen copy. The TikTok line is tracked separately as platform copy. The music notes describe the intended mood.

Dr. CK chose the first crimson-card treatment for the November 5 morning handoff reel. The hook enters at 0.63 seconds, and the tips are retimed to the repeating bright accents at 1.38, 4.46, and 7.58 seconds. Each tip is fully visible on its cue. The ten-second excerpt begins at 4.03 seconds in Javi Canto’s “12 AM Text” instrumental. [Source WAV](https://drive.google.com/file/d/1FjLu3KSfyj8s_d_unW3kOfXe8O2CS-Wk/view?usp=drivesdk)

Use C3 Global’s crimson `#C91B19` for contained translucent cards and accents, crisp white `#FFFFFF`, and swatch 5, “Deeper, richer,” for the metallic finish. Its base is `#A9574A` and its highlight is `#F1B9A5`. Dr. CK liked the crimson card, message bubbles, and white handwritten note treatments. Put the hook in its own card near the top and the tips in a separate card, bubble stack, or note over the desk. All copy has a contained background for legibility. [C3 Global metallic finish reference](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/C3G metallic finish hex codes.png>)

## Nov 4 · How to hand off your community or team in 3 steps

Matched. [Binder handoff, 10-second take](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/Animate_image_into_video_clip_20261025184456.mp4>) is the trial source. [Shorter alternate](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/Animate_image_into_video_clip_20261025184750.mp4>) covers the same scene. [Content OS row](https://app.notion.com/p/403d06348596814fa738c0016589a8f4)

**Scene.** In the Recovery and Implementation Studio, a binder slides across a table toward someone out of frame, whose hand opens it. The labels on its spine are added in the edit.

**Hook.** How to hand off your community or team in 3 steps

**Tips, one per beat**

1. Write down the rhythm.
2. Write down the rules.
3. Write down the reasons.

**Music.** calm and confident.

**TikTok line.** DM me SHIFT and I'll send you the readiness index.

## Nov 8 · 3 STEPS to an invitation people say yes to

Matched by action and setting. [Writing on the balcony, 10-second take](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/Woman_writing_invitations_on_bal…_20261025190455.mp4>) shows Dr. CiCi writing beside a mug with the city behind her. [Content OS row](https://app.notion.com/p/403d06348596814ca580fd1236ea6855)

The revised export uses the blush-pink coat and pink boots from Doctor_writing_thank-you_note_0255519d_1080p.mp4. It has a taller opening envelope, numbered full-line tips, and a centered single-line hook. KOLA’s “French Toast” begins at 1:27.84 in the source track, with tip cues at 2.00, 5.04, and 8.17 seconds. The earlier centered charcoal-card visual remains available as an alternative.

**Scene.** Sunday evening on the penthouse balcony, in warm light. Dr. CiCi sits with a warm drink and a notebook, writing invitations, with the city soft in the background.

**Hook.** 3 STEPS to an invitation people say yes to

**Tips, one per beat**

1. Use their first name.
2. Say what they'll do when they arrive.
3. Give one day and one time.

**Music.** gentle acoustic guitar.

**TikTok line.** DM me EXPERIENCE and I'll send you the full diagnostic.

## Nov 11 · 4 EASY ways to spot where new visitors get stuck

Candidate. [Nov LS 1 (bad quality)](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/Nov LS 1 (bad quality).mp4>) shows Dr. CiCi at a large display. [Interface review](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Woman_reviewing_interface_at_con…_c6720f66_t0-4.9_1080p.mp4>) is a second option. The repeated visitor-path detail and rose-gold circles still need a picture check. [Content OS row](https://app.notion.com/p/403d06348596813fbfe4f0429a38ea2b)

Dr. CK subsequently chose the longer ten-second November screen clip. The music review uses that full clip at normal speed, with numbered full-line tips on charcoal and a centered crimson hook. Yellen’s “Closer Than Before” begins at 1:28.33 in the source track.

**Scene.** Dr. CiCi stands before a wall screen that replays a visitor's path through a virtual space. The path stalls in the same spot three times, and each spot is circled in rose gold.

**Hook.** 4 EASY ways to spot where new visitors get stuck 👇

**Tips, one per beat**

1. Watch someone click around for one minute.
2. Say nothing and write down every pause.
3. Circle the spots where they stop.
4. Fix each spot with a sign or a shorter step.

**Music.** soft, curious piano.

**TikTok line.** DM me EXPERIENCE and I'll send you the full diagnostic.

## Nov 15 · SAVE THIS: 4 checks before you post an announcement

Candidate. [Desk review](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/download (2).mp4>) shows Dr. CiCi at a warmly lit desk. Check for the glasses removal and confirm the announcement setup. [Content OS row](https://app.notion.com/p/403d06348596818dac34fc55b73825e6)

The edit uses the available ten-second black-sweater desk-review clip. Its hair arrangement differs from the approved Notion still. The revised treatment pairs a centered crimson hook card with four numbered full-line tips on a wider white note, using 60-pixel Caveat handwriting. Fobos’s “Arpeggiated Alterations” begins at 2:46.64 in the source track.

**Scene.** At the home study desk, Dr. CiCi pauses above an announcement draft, takes off her glasses, and reads it again.

**Hook.** SAVE THIS: 4 checks before you post an announcement

**Tips, one per beat**

1. Read it as someone who joined yesterday.
2. Circle every word they wouldn't know.
3. Swap each one for a plain word.
4. Add the time zone to every date.

**Music.** soft piano.

**TikTok line.** DM me EXPERIENCE and I'll send you the full diagnostic.

## Nov 18 · Let's make a plan: 4 ways to welcome someone new

Candidates. [Notebook in the suite](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Woman_writing_in_notebook_9167a2cf_1080p.mp4>) and [Welcoming gesture](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Raw Clips/Woman_welcoming_someone_into_clinic_1080p_20261025205844.mp4>) cover parts of the brief. The name-card action still needs a match. [Content OS row](https://app.notion.com/p/403d0634859681c8abadd5014d43b7e0)

The review export uses the notebook clip matching the approved outfit and set, with a clipboard list and stamped crimson hook. Clejan’s “Star Chariot” begins at 0:27.51 in the source track.

**Scene.** In the Consultation Suite, Dr. CiCi writes in a notebook while a hand pins a name card to the wall beside a calendar.

**Hook.** Let's make a plan: 4 ways to welcome someone new

**Tips, one per beat**

1. Pick one person who says hello.
2. Use the same message each time.
3. Add their name.
4. Ask them to try one small thing.

**Music.** warm and light.

**TikTok line.** DM me SHIFT and I'll send you the readiness index.

## Nov 22 · Let's make a plan: 3 ways to say thank you the way each person likes

Candidates. [Place card](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Woman_adjusting_place_card_cc50a9b3_1080p.mp4>) and [Thank-you note](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Dr. CiCi - Ai/Cinema:Videos/Cine Clinic Notes/Dr._CiCi_writing_thank-you_note_6039f6e3_1080p.mp4>) cover the two actions. Check wardrobe and setting continuity before cutting them together. [Content OS row](https://app.notion.com/p/403d0634859681aa9df3fbf14f4500b9)

The review export uses the black-sweater thank-you-note clip matching the approved still, with three appreciation cards. Terem’s “Moment of Truth” begins at 0:30.97 in the source track.

**Scene.** At the kitchen island, set for Thanksgiving with autumn decor, Dr. CiCi arranges place cards and a small stack of thank-you notes.

**Hook.** Let's make a plan: 3 ways to say thank you the way each person likes

**Tips, one per beat**

1. Say it out loud in front of the group.
2. Send a private note.
3. Ask each person which they prefer.

**Music.** warm piano.

**TikTok line.** DM me CQ and I'll send you the compass.

## Nov 25 · Replaced by a YAP

At Dr. CK’s request on November 5, the garage Clinic Note was removed from the production queue and its specific Content Library row was moved to Notion Trash. It is recoverable. Do not produce this reel.

## Nov 29 · It's time to leave the pressure on the table: 3 ways to rest on purpose

Ready for listening review using the supplied tree-decorating video, preserved at native 720x1280 and 24 fps. Centered crimson holiday hook with copper ornaments; accumulating numbered charcoal cards. Wes Harris’s “a lo fi christmas” begins at 2:06.036, with reveals at frames 48, 119, and 189. The earlier still animation is superseded. [Review export](</Users/c3global/Library/Mobile Documents/com~apple~CloudDocs/C3 Global/Clients/Faceless48 Demo/November Clinic Notes/F48 Project/out/nov-29-christmas-rest-video-v4.mp4>)

**Scene.** In the living room, Dr. CiCi hangs the first ornaments on the Christmas tree, with a lamp glowing beside her. There is no laptop in sight.

**Hook.** It's time to leave the pressure on the table: 3 ways to rest on purpose 🎄

**Tips, one per beat**

1. Pick one hour you won't check anything.
2. Tell your team or members you're away.
3. Plan a slow week ahead of time.

**Music.** very soft ambient with a hint of bells.

**TikTok line.** DM me SHIFT and I'll send you the readiness index.

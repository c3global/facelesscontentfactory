# Carousel Slide Copy (Oct 15 to Nov 2)

Oct 15, 2026 · @Dr. Charity Campbell-Kapela

Slide-by-slide copy and captions for the six remaining carousels, written to be dropped into the studio and then logged into the Content Library fields once you approve. Each carousel carries one ask, a hook from the Approved Copy Library, and platform captions.

## Thu Oct 15: Your team isn't resisting the AI tool. They're in the neutral zone.

Keyword AIREADY (closing slide swapped from SHIFT per your call). Post type: Audience Take. Hook: Hooks & Caption Starters Page 1 #15. Instagram, Facebook and LinkedIn, 5:53 PM ET. Source to verify before publishing: William Bridges, Managing Transitions (1991).

### Slides

- **Slide 1, cover**
  - Headline: So you think your team doesn't like the new AI app?
  - Second line: Here is what low use after an AI launch usually means.
  - Small text: Swipe to find your team's stage.
- **Slide 2**
  - Headline: Low use after launch looks like pushback.
  - Body: The usage numbers are flat three weeks in, so it's tempting to call it resistance. William Bridges described a better reading: people move through three stages, and the middle one looks a lot like pushback.
- **Slide 3**
  - Headline: Stage 1: The old way ends.
  - Body: Before anything new can take hold, people let go of something: a routine, a shortcut, a way of being good at their job. You'll hear it as "the old way worked fine."
  - Your move: Ask what the old way did for them, and say out loud that it mattered.
- **Slide 4**
  - Headline: Stage 2: The neutral zone.
  - Body: The old way is gone and the new one hasn't taken hold yet. People feel unsure, so they open the tool, close it, and go back to what they know.
- **Slide 5**
  - Headline: What the neutral zone looks like with AI.
  - Body: Logins start strong and fade after the first week. People copy answers out of the tool and paste them into the old template. They ask a colleague a quick question instead of asking the tool, and they say they'll try it when things calm down.
- **Slide 6**
  - Headline: Your move in the neutral zone.
  - Body: Give people a safe place to practice: one real task to try, a short weekly check-in, and permission to say "I'm not sure this works yet." Honest reports from a small group will teach you more than another reminder email.
- **Slide 7**
  - Headline: Stage 3: The new beginning.
  - Body: It shows up as a first real use. Someone finishes a task faster, or catches something the old way missed, and tells a colleague about it.
  - Your move: Name the early win and let the person who had it tell the story.
- **Slide 8**
  - Headline: Which stage is your team in?
  - Body: People still defend the old way: stage one. The tool gets opened and then abandoned: stage two. Someone tells a story about it without being asked: stage three. Match what you hear to what the usage data shows.
- **Slide 9, closing**
  - Headline: Not sure where your team is?
  - Instagram and Facebook version: Comment AIREADY and let's see whether your organization is actually ready.
  - LinkedIn version: Take the AI Advantage Audit. The link is in the post.

### Captions

**Instagram and Facebook**

Here's everything you wanted to know about low AI use after launch but were too afraid to ask 🤔

If the usage numbers are flat three weeks in, your people may not be resisting the tool at all. William Bridges described three stages of any transition, and the middle one, the neutral zone, looks a lot like pushback because the old way is gone and the new way hasn't taken hold.

Swipe to find which stage your team is in and the one move that fits each one ➡️

Comment AIREADY and let's see whether your organization is actually ready. ✨

\#organizationaldevelopment #changemanagement #AIadoption

**LinkedIn**

Here's everything you wanted to know about low AI use after launch but were too afraid to ask.

When usage is flat three weeks after an AI launch, the easy reading is resistance. William Bridges offered a more useful one: people move through an ending, a neutral zone, and a new beginning, and the neutral zone looks a lot like pushback because the old way is gone and the new way hasn't taken hold. 🔍

The carousel walks through all three stages, what each one looks like with an AI tool, and one move for each.

To see whether your organization is actually ready, take the AI Advantage Audit: https://www.c3global.co/aiaudit

\#organizationaldevelopment #changemanagement #AIadoption

### Content Library fields to update after approval

Hook Template Used: Hooks & Caption Starters Page 1 #15 | Post type: Audience Take. CTA Keyword AIREADY, CTA Link https://www.c3global.co/aiaudit, Marky Caption (the versions above), Doc Link (this doc), Notes (last slide Comment AIREADY).

## Mon Oct 19: Why isn't anyone using it? A diagnosis for AI rollouts

Keyword AIREADY. Post type: Audience Take. Hook: Hooks & Caption Starters Page 1 #17. Instagram, Facebook, LinkedIn and TikTok, 5:53 PM ET (Monday is a movable placeholder day). Sources to verify before publishing: Davis, 1989, MIS Quarterly (usefulness and ease of use); Lewin, 1947 (unfreezing).

### Slides

- **Slide 1, cover**
  - Headline: Why is nobody using the AI app you just launched?
  - Small text: Four causes to check, in order.
- **Slide 2**
  - Headline: Low use is a symptom.
  - Body: Each symptom points to a likely cause. Find the cause before you buy more training. Here are four to check, with the question that reveals each one.
- **Slide 3**
  - Symptom: People try it once and don't come back.
  - Likely cause: It isn't useful for their work.
  - Ask: What did you hope it would do for you?
- **Slide 4**
  - Symptom: They say it takes too much effort.
  - Likely cause: It isn't easy to use on a busy day.
  - Ask: Where did you get stuck?
- **Slide 5**
  - Symptom: They keep using the old process next to it.
  - Likely cause: Nobody helped them let go of the old way.
  - Ask: What does the old way do for you that this doesn't?
- **Slide 6**
  - Symptom: When it gives a wrong answer, nothing happens.
  - Likely cause: Nobody owns it after launch.
  - Ask: Whose name is on the weekly review?
- **Slide 7**
  - Headline: How to ask.
  - Body: Pick a handful of people who use the tool, or were supposed to. Ask the four questions in a short one-on-one conversation and write down their exact words.
- **Slide 8**
  - Headline: Which cause to check first.
  - Body: Start with usefulness. In Davis's research it was the stronger predictor of use, and training rarely fixes a tool that doesn't help with the work.
- **Slide 9**
  - Headline: Then work down the list.
  - Body: Ease of use next, then letting go of the old way, then the owner. Change one thing at a time so you can see what moved the usage.
- **Slide 10, closing**
  - Headline: Which cause is yours?
  - Instagram, Facebook and TikTok version: Comment AIREADY and let's see whether your organization is actually ready. (TikTok: DM me AIREADY.)
  - LinkedIn version: Take the AI Advantage Audit. The link is in the post.

### Captions

**Instagram and Facebook**

DON'T PANIC. 😅 We can fix an AI app nobody is using, and the first step is finding the cause.

Low use is a symptom, and each symptom points to a different likely cause: the tool isn't useful for the work, it isn't easy to use, nobody helped people let go of the old way, or nobody owns what happens after launch.

Swipe for the four symptoms, the question that reveals each cause, and which one to check first ➡️

Comment AIREADY and let's see whether your organization is actually ready. ✨

\#organizationaldevelopment #changemanagement #AIadoption

**TikTok**

DON'T PANIC. 😅 We can fix an AI app nobody is using, and the first step is finding the cause. Swipe for the four symptoms, the question that reveals each cause, and which one to check first ➡️

DM me AIREADY and let's see whether your organization is actually ready. ✨

\#organizationaldevelopment #changemanagement #AIadoption

**LinkedIn**

DON'T PANIC. We can fix an AI app nobody is using, and the first step is finding the cause. 🔍

Low use is a symptom, and each symptom points to a different likely cause: the tool isn't useful for the work, it isn't easy to use, nobody helped people let go of the old way, or nobody owns what happens after launch. The carousel pairs each symptom with the question that reveals its cause and ends with which one to check first.

To see whether your organization is actually ready, take the AI Advantage Audit: https://www.c3global.co/aiaudit

\#organizationaldevelopment #changemanagement #AIadoption

### Content Library fields to update after approval

Hook Template Used: Hooks & Caption Starters Page 1 #17 | Post type: Audience Take. CTA Keyword AIREADY (already set). Marky Caption, Doc Link.

## Thu Oct 22: Where each box breaks a green report

Keyword SHIFT. Post type: Audience Take. Hook: Hooks & Caption Starters Page 3 #15. Instagram, Facebook and LinkedIn, 5:53 PM ET. Source to verify before publishing: Marvin Weisbord, six-box model (1976).

### Slides

- **Slide 1, cover**
  - Headline: Your status report says green, so why does your team look exhausted?
  - Small text: Six places to look.
- **Slide 2, Purposes**
  - Headline: Box 1: Purposes
  - Body: A report is green against a goal. Ask three people to state the goal in their own words. If you hear three versions, green means something different to each of them.
  - Ask: What is green measured against?
- **Slide 3, Structure**
  - Headline: Box 2: Structure
  - Body: When nobody is sure who owns a decision, the work still gets done, and the report describes what happened instead of what was decided.
  - Ask: Who decides this, and do they know it?
- **Slide 4, Relationships**
  - Headline: Box 3: Relationships
  - Body: A handoff between two people or two teams is where a problem can sit for a week while each side assumes the other one flagged it.
  - Ask: Where does one team wait on another?
- **Slide 5, Rewards**
  - Headline: Box 4: Rewards
  - Body: People report what gets rewarded. If green earns thanks and red earns questions, you will see more green.
  - Ask: What happens to the first person who writes red?
- **Slide 6, Leadership**
  - Headline: Box 5: Leadership
  - Body: Your team watches how you react to bad news and adjusts what they bring you. Your reaction is part of the report.
  - Ask: When did you last thank someone for a problem?
- **Slide 7, Helpful mechanisms**
  - Headline: Box 6: Helpful mechanisms
  - Body: Budgets, meetings and reports are supposed to coordinate the work. When the report doesn't match the list your team keeps for itself, the mechanism is hiding something.
  - Ask: Does the report match the team's own list?
- **Slide 8, closing**
  - Headline: Which box broke yours?
  - Instagram and Facebook version: Comment SHIFT and I'll send you the readiness index.
  - LinkedIn version: Take the Shift Index. The link is in the post.

### Captions

**Instagram and Facebook**

How to find where a green report breaks. 📒 Here's my fundamental guide:

When the status says green and your team looks stretched, Marvin Weisbord's six boxes give you six places to look: purposes, structure, relationships, rewards, leadership, and helpful mechanisms. Each slide takes one box and gives you the question to ask.

Swipe through all six and notice which one makes you pause ➡️

Comment SHIFT and I'll send you the readiness index. 📊

\#organizationaldevelopment #changemanagement #leadership

**LinkedIn**

How to find where a green report breaks. Here's my fundamental guide.

When the status says green and your team looks stretched, Marvin Weisbord's six boxes give you six places to look: purposes, structure, relationships, rewards, leadership, and helpful mechanisms. Each slide takes one box and gives you the question to ask. 🔍

To see where your organization stands, take the Shift Index: https://www.c3global.co/shiftindex

\#organizationaldevelopment #changemanagement #leadership

### Content Library fields to update after approval

Hook Template Used: Hooks & Caption Starters Page 3 #15 | Post type: Audience Take. CTA Keyword SHIFT (already set). Marky Caption, Doc Link. The Pain Named field mentions an event team; the slides speak to "you" with no hypothetical team, per the synopsis, so you may want to adjust that field.

## Mon Oct 26: 7 things to check before you trust a green status

Keyword SHIFT. Post type: Audience Take. Hook: Hooks & Caption Starters Page 1 #22 (already on the row). Instagram, Facebook, LinkedIn and TikTok, 5:53 PM ET. The Notion title is "Seven signs your green is borrowed"; the cover uses your updated line. Sources to verify before publishing: Kahn and colleagues, 1964 (role overload); Edmondson, 1996; Vaughan, 1996.

### Slides

- **Slide 1, cover**
  - Headline: Is your green status report telling you the truth?
  - Small text: 7 things to check before you trust it. Keep count as you swipe.
- **Slide 2**
  - Headline: 1. Nobody can say what red would look like.
  - Body: If the team can't describe the point where green turns red, the color is a feeling and not a measurement.
- **Slide 3**
  - Headline: 2. Last month's yellow became this month's green.
  - Body: Ask what changed besides the wording. If nothing did, the green is borrowed.
- **Slide 4**
  - Headline: 3. The team keeps its own list.
  - Body: A spreadsheet, a notebook or a private chat that the report never sees is usually closer to the work than the report is.
- **Slide 5**
  - Headline: 4. The same people are covering a gap.
  - Body: If the work needs ten people and the plan funds seven, the missing three don't disappear. Their work lands on the seven, often at night.
- **Slide 6**
  - Headline: 5. Nobody has written red in months.
  - Body: In one well-known hospital study, the better-performing units reported more errors, because their people felt safe saying so.
- **Slide 7**
  - Headline: 6. A warning keeps coming up and "it's been fine."
  - Body: Each time nothing goes wrong, the warning gets easier to ignore. Diane Vaughan called this the normalization of deviance.
- **Slide 8**
  - Headline: 7. The report hasn't surprised you in a long time.
  - Body: A complicated project that never surprises you is worth a question about whether it feels safe to bring one.
- **Slide 9, closing**
  - Headline: Count your signs.
  - Body: Zero to two: your green is probably earned, so keep asking. Three or four: follow one item from the team's list to the report. Five or more: your green is likely borrowed, so start there.
  - Instagram, Facebook and TikTok version: Comment SHIFT and I'll send you the readiness index. (TikTok: DM me SHIFT.)
  - LinkedIn version: Take the Shift Index. The link is in the post.

### Captions

**Instagram and Facebook**

CHECKLIST ✅ 7 things to check before you trust a green status 👇

A green report can be accurate, and it can also be borrowed from optimism instead of evidence. The signs are usually visible from where you sit: a yellow that turned green with only the wording changed, a team list the report never sees, the same people covering a gap at night, and a long stretch with no red at all.

Swipe, keep count as you go, and see how your report scores ➡️

Comment SHIFT and I'll send you the readiness index. 📊

\#organizationaldevelopment #changemanagement #leadership

**TikTok**

CHECKLIST ✅ 7 things to check before you trust a green status. Swipe, keep count, and see how your report scores ➡️

DM me SHIFT and I'll send you the readiness index. 📊

\#organizationaldevelopment #changemanagement #leadership

**LinkedIn**

CHECKLIST: 7 things to check before you trust a green status. ✅

A green report can be accurate, and it can also be borrowed from optimism instead of evidence. The carousel lists seven signs, from a yellow that turned green with only the wording changed to a long stretch with no red at all, and lets you score your own report as you swipe.

To see where your organization stands, take the Shift Index: https://www.c3global.co/shiftindex

\#organizationaldevelopment #changemanagement #leadership

### Content Library fields to update after approval

Hook Template Used is already set. Title (optional): "7 things to check before you trust a green status". Marky Caption, Doc Link.

## Thu Oct 29: What you notice first, and have never written down

Keyword AIREADY (the row's CTA fields say AIREADY; the Notes field says PRESENCE and the Week 5 script page uses PRESENCE for this day's explainer, so please confirm which you want before this is scheduled). Post type: Audience Take. Hook: Hooks & Caption Starters Page 2 #6 (already on the row). Instagram, Facebook, LinkedIn and TikTok, 5:53 PM ET. Source to verify before publishing: Michael Polanyi, The Tacit Dimension (1966).

### Slides

- **Slide 1, cover**
  - Headline: Could an app built from your book do what you do?
  - Small text: Seven questions about what you know and have never written down.
- **Slide 2**
  - Headline: 1. What do you notice first when someone sits down with you?
  - Body: Write down the first thing, before they say a word.
- **Slide 3**
  - Headline: 2. What tells you a conversation just changed direction?
  - Body: Name the sign you respond to before you could explain it.
- **Slide 4**
  - Headline: 3. When do you stay quiet on purpose?
  - Body: Write down how long you wait and what you are waiting for.
- **Slide 5**
  - Headline: 4. What do you refuse to say or do, even when asked?
  - Body: Your refusals are part of the method.
- **Slide 6**
  - Headline: 5. What do you check in a report before you read the numbers?
  - Body: The order you look in is expertise too.
- **Slide 7**
  - Headline: 6. What question do you ask that clients don't expect?
  - Body: Write it down along with what the answer tells you.
- **Slide 8**
  - Headline: 7. When do you know this one needs different help than you can give?
  - Body: Name the moment you hand someone to a person who is better placed.
- **Slide 9, closing**
  - Headline: Could your book have given these answers?
  - Body: If an app is built only from what you have written, it will miss what you wrote just now.
  - Instagram, Facebook and TikTok version: Comment AIREADY and let's see whether your organization is actually ready. (TikTok: DM me AIREADY.)
  - LinkedIn version: Take the AI Advantage Audit. The link is in the post.

### Captions

**Instagram and Facebook**

This is an OPEN LETTER ✉️ for all you coaches, consultants and facilitators who are thinking about putting your method inside an AI app. ✍️

Michael Polanyi wrote that we know more than we can tell. The part of your expertise that you do by feel, what you notice first, when you stay quiet, what you refuse to do, is the part that rarely makes it into a book or a transcript.

Swipe for seven questions that bring it to the surface before anyone builds anything from what you have written ➡️

Comment AIREADY and let's see whether your organization is actually ready. ✨

\#AIadoption #expertise #consulting

**TikTok**

This is an OPEN LETTER ✉️ for all you coaches, consultants and facilitators who are thinking about putting your method inside an AI app. Swipe for seven questions that surface what you notice first ➡️

DM me AIREADY and let's see whether your organization is actually ready. ✨

\#AIadoption #expertise #consulting

**LinkedIn**

This is an open letter for the coaches, consultants and facilitators who are thinking about putting their method inside an AI app. ✉️

Michael Polanyi wrote that we know more than we can tell. What you notice first, when you stay quiet and what you refuse to do rarely make it into a book or a transcript. The carousel gives you seven questions to bring that knowledge to the surface before anyone builds from what you have written.

To see whether your organization is actually ready, take the AI Advantage Audit: https://www.c3global.co/aiaudit

\#AIadoption #expertise #consulting

### Content Library fields to update after approval

Hook Template Used is already set. CTA Keyword stays AIREADY unless you choose otherwise; the Notes field says the last slide is PRESENCE and would need updating either way. Marky Caption, Doc Link.

## Mon Nov 2: What your AI app should decline

Keyword AIREADY. Post type: Audience Take. Hook: Hooks & Caption Starters Page 1 #11 (already on the row). Instagram, Facebook, LinkedIn and TikTok, 5:53 PM ET (Monday is a movable placeholder day). Previews the Wed Nov 4 talking head.

### Slides

- **Slide 1, cover**
  - Headline: What should your AI app refuse to answer?
  - Small text: Six situations that need a person.
- **Slide 2**
  - Headline: Situations 1 and 2
  - A person is grieving.
  - Someone shares a medical concern.
- **Slide 3**
  - Headline: Situations 3 and 4
  - Someone asks a legal question.
  - Someone brings a complaint about a staff member.
- **Slide 4**
  - Headline: Situations 5 and 6
  - Someone asks whether to fire or discipline a person.
  - Someone says they are in danger or thinking of harming themselves.
- **Slide 5**
  - Headline: What the app says in that moment
  - Body: It says plainly that this one needs a person, tells the user what happens next, and doesn't improvise advice. For example: "This deserves a real conversation, so I'm passing it to a member of the team who can help. You'll hear from them directly." For the last situation, it shares a crisis resource right away.
- **Slide 6**
  - Headline: Who sees the handoff
  - Body: Decide in advance who receives each type of handoff, and how quickly they respond. A handoff that lands in an unread inbox is another way of declining to help.
- **Slide 7, closing**
  - Headline: What does yours decline?
  - Instagram, Facebook and TikTok version: Comment AIREADY and let's see whether your organization is actually ready. (TikTok: DM me AIREADY.)
  - LinkedIn version: Take the AI Advantage Audit. The link is in the post.

### Captions

**Instagram and Facebook**

What does the perfect AI app decline to answer? Check this out. 👇

A well-built app knows where your method says "stop, this one needs a person." Grief, a medical concern, a legal question, a complaint about a staff member, a question about firing someone, and a person in danger all belong on that list.

Swipe for the six situations, what the app should say in that moment, and who should see the handoff ➡️

Comment AIREADY and let's see whether your organization is actually ready. ✨

\#AIadoption #expertise #consulting

**TikTok**

What does the perfect AI app decline to answer? Check this out. 👇 Swipe for six situations that need a person, and what the app should say in each one ➡️

DM me AIREADY and let's see whether your organization is actually ready. ✨

\#AIadoption #expertise #consulting

**LinkedIn**

What does the perfect AI app decline to answer? Here is a starting list. 🔍

A well-built app knows where your method says "stop, this one needs a person." The carousel covers six situations, what the app should say in that moment, and who should see the handoff.

To see whether your organization is actually ready, take the AI Advantage Audit: https://www.c3global.co/aiaudit

\#AIadoption #expertise #consulting

### Content Library fields to update after approval

Hook Template Used is already set. Marky Caption, Doc Link.

# Sales Page Structures

## Based On: An offer to make passive income with Instagram

### High-Level Structure:

**Logo/Branding Header**

**Primary CTA Button** - Direct action-oriented command

**Hook Statement (Italicized)** - Specific promise with concrete numbers tied to current follower count

**CTA Button**

**Personal Income Credibility Statement** - First-person daily income claim with specific dollar amount

**Social Proof Element** - Screenshot of revenue over time period (6 months)

**Urgency/Scarcity Statement** - Algorithm update creates limited-time opportunity

**CTA Button**

**Main Headline** - Inclusive promise (anyone can do this) + objection handled in parentheses

**Subheadline** - "Creating passive income requires NO:"

**Objection Elimination List** - 9 "NO" statements with red X icons (no audience, no experience, no showing face, etc.)

**CTA Button**

**"Here's How It Works" Section** - 3-step visual process breakdown (numbered graphics with descriptions)

**Transition Copy** - "I figured out the formula" statement + call to follow tutorials

**Student Success Story #1** - Specific name, results, and timeframe (Diane - $630 in 11 days)

**"What's Included?" Section Headline**

**Bulleted Benefits List** - 8+ benefits with numbered icons, each highlighting specific outcome or learning

**Price Display** - Strikethrough original price (~~$497~~) showing discounted price ($247)

**Additional Features List** - More detailed bullets about what's taught

**CTA Buttons (2 different versions)**

**Video Preview Section** - "Want a sneak-peek preview?" + embedded video

**CTA Button**

**FAQ-Style Content Block #1** - "Do I have to show my face?" with detailed answer

**CTA Buttons**

**Bonus Section** - Free bonus training (Meta monetization) with strikethrough price

**Video Section #2** - "Here's why every human should create a digital product"

**Student Success Story #2** - Renata (150 sales, $14,550 in 60 days)

**CTA Button**

**Personal Income Proof** - 6-month earnings statement with screenshot ($700K+)

**Income Screenshot Gallery** - Multiple revenue screenshots from platform

**Image CTA** - Clickable revenue screenshot leading to purchase

**Student Success Story #3** - Charlotte (110 days later comment/testimonial)

**Student Success Stories #4 & #5** - Katie ($130 overnight) and Brooke ($600 in 4 days)

**Video Section #3** - "Want to dive deeper?" free training video (18+ minutes)

**Short Explainer Video Section** - "Watch this short video that explains everything"

**CTA Button**

**FAQ-Style Content Block #2** - "Will I need to invest in equipment?" with photo proof (cracked iPhone)

**CTA Button**

**Final Discount Code** - Limited-time coupon code (META25 for 25% off)

---

## Based On: A course teaching how to create viral digital products

### High-Level Structure:

**Logo/Branding Header**

**Primary CTA Button** - Direct action-oriented command

**Hook Statement** - Educational promise about creating product even if starting from scratch

**CTA Button**

**Personal Credibility Statement** - Daily sales volume (136 product sales every single day)

**Social Proof Element** - Screenshot of sales over time period (6 months)

**Relatable Problem Statement (Italicized)** - "Every single day, I get DMed or emailed asking..."

**CTA Button**

**Main Headline** - Inclusive promise (anyone can do this) + objection handled in parentheses

**Subheadline** - "Creating a viral digital product requires NO:"

**Objection Elimination List** - 8 "NO" statements with red X icons (no expensive equipment, no experience, no audience, etc.)

**CTA Button**

**"Here's How It Works" Section** - 3-step visual process with icons and descriptions

**Transition Copy** - "So simple, right? I did all the heavy lifting" + call to follow timeline

**Student Success Story #1** - Laura (20 sales, $650 in first week)

**"What's Included?" Section Headline**

**Bulleted Benefits List** - 10+ benefits with numbered icons, specific outcomes and learnings

**Price Display** - Single price point ($300)

**CTA Buttons (2 different versions)**

**Video Preview Section** - "Want a sneak-peek preview?" + embedded video

**CTA Button**

**FAQ-Style Content Block** - "Maria, what do I need to create a viral digital product?" with detailed answer

**CTA Buttons (2 different versions)**

**Bonus Section** - "Flop To Viral Scale" tool with strikethrough price

**Video Section** - "Here's why every human should create a digital product" + embedded video

**Student Success Story #2** - Lynsay (5 sales, $1618 in first 4 hours)

**CTA Button**

**Personal Credibility Statement** - "mastered the art of making digital products go viral" over 4 years

**Proof Image Gallery** - Multiple product screenshots/examples

**Student Success Story #3** - Hana (33 sales, $1168 in first 2 weeks)

**CTA Button**

**More Proof Screenshots**

**Student Success Story #4** - Hayleye (made first sale)

**More Proof Screenshots**

**Student Success Story #5** - Gabrielle (double figures in first 3 days pre-selling)

**CTA Button**

**More Proof Screenshots**

**Large Number Display** - "1 digital products sold" with contextual explanation

**Explanatory Copy Block** - Philosophy about imperfection and authenticity leading to viral success

**"Have More Questions?" Section** - Directing to FAQ with link

**CTA Button**

**Final Discount Code** - Limited-time coupon code (SAVE200 for $200 credit)

---

## Based On: A workshop for coaches to build a call-free business model

### High-Level Structure:

**Logo/Branding Header**

**Workshop Cover Image**

**Main Value Proposition Headline** - Three-part promise (support premium clients, charge premium prices, stack MRR)

**Subheadline (Italicized)** - "without" statement removing main objection/pain point

**Embedded Video** - With play/pause controls visible

**CTA Button** - Direct price point visible in button text ($17 USD)

**Three Testimonial Quotes** - Short format with first names only

**Three Emoji-Led Problem/Desire Statements** - Each starts with emoji, poses question or desire

**Transitional Copy Block** - "Chances are you didn't start your business to..." empathy statements

**Invitation Statement** - Direct invitation to workshop with promise

**CTA Button**

**Three More Testimonial Quotes** - Longer format with full names and initial

**"What We Cover During the Workshop" Section Headline**

**Checklist of Benefits/Learnings** - 11 items with checkmark bullets, specific outcomes and methods

**Two Longer Testimonial Quotes** - Detailed feedback with names

**CTA Button**

**Image**

**Value Proposition Headline (Variation)** - "Give us [time] and [price] and we'll share how..."

**CTA Button**

**Social Proof Section Headline** - "What 100+ coaches & experts discovered..." with subheadline

**Filter/Tab** - "All" option for testimonials

**Testimonial Grid** - 20+ testimonials with names, varying lengths, with "LOAD MORE" button

**Founder Story Section** - "Hey, we're [Names]!" with photo

**Personal Story Copy Block** - Backstory about why they said no to traditional model

**Problem Statement** - What traditional model would create for them

**Solution Introduction** - How they found alternative

**Bolded Key Statement** - Definition of their method

**Benefit Statement** - What it allows them to maintain

**Invitation** - "Now we're excited to show you how to do the same"

**Image**

**Main Offer Headline Repeated** - Reinforcement of core promise

**CTA Button**

**FAQ Section** - "Got a question?" with 9 Q&A pairs using question as subheadline format

**Final CTA Button**

---

## Based On: A workshop teaching subscription-based business growth

### High-Level Structure:

**Countdown Banner** - "83% OFF CODE AUTOMATICALLY APPLIED" with deadline and emoji

**Contact Info** - WhatsApp and email prominently displayed at top

**Target Audience Statement** - "FOR ANYONE WHO'S DONE WITH..." pain point

**Main Headline** - How I Used formula with specific numbers ($97/week, $100K/Mo, 2 hours/day)

**Subheadline** - Product name with promise (autopilot, no sales calls, even if objections)

**Embedded Video** - With enable sound control

**Social Proof Badge** - Star rating with specific number of verified students

**Testimonial Image** - Verified customer with specific results

**Urgency Badge** - "ONLY A FEW DAYS LEFT"

**Price Display** - Large strikethrough (~~$147~~) with discounted price ($7)

**Savings Statement** - "You're Instantly Saving $140.00"

**Reason for Discount** - Explanation about launch and gathering testimonials

**Limited Deal Badge** - "83% OFF Deal Available today!"

**CTA Button** - "SEND MY ACCESS"

**Social Proof Badge (Repeated)**

**Money-Back Guarantee Badge** - 30-day with shield emoji

*Note: Main content sections repeat 2-3 times throughout the page for emphasis*

**Section Headline (Italicized)** - "THIS IS EXACTLY HOW THE 'SUBSCRIPTION VORTEX' FOLLOWS THE BILLION DOLLAR GOLD RUSH"

**Explanatory Copy Block** - Describes the counterintuitive shortcut, contrasts with traditional methods

**Four "Without" Statements** - Checkmark-X bullets listing what's NOT needed

**Embedded Video**

**CTA Button**

**Money-Back Guarantee**

**Social Proof Badge**

**Testimonial**

**Section Headline (Italicized)** - "THE SUBSCRIPTION VORTEX IS A SHORTCUT"

**Before/After Statement** - Contrasting previous business model with new results

**"How It Works" Section** - 4 numbered steps

**"Why It Works" Explanation**

**"What This Means For You" Checklist** - 4 checkmark items

**Contrast Section** - "While others are..." with 4 X bullets

**Benefits List** - Arrow bullets with bold outcomes

**Choice Statement** - "The choice is simple:" with two options

**Philosophy Statement** - What the product really is (beyond just strategy)

**Three Pain Point Questions** - Building empathy and desire

**Closing Statement** - "Then grab this system below"

**CTA Button**

**Money-Back Guarantee**

**Social Proof Badge**

**"GIVE ME PROOF!" Section Headline**

**Personal Results** - Series of "I get/have..." statements each followed by screenshot proof (6-7 proof images)

**Price/Offer Block (Repeated)**

**CTA Button**

**Social Proof Badge**

**Money-Back Guarantee**

**Social Proof Headline** - "862+ verified students are winning..."

**Subheadline (Italicized)** - "THEIR SUCCESS STORIES SPEAK LOUDER THAN I EVER COULD"

**Social Proof Badge**

**Testimonial Screenshot Grid** - 9-10 images of testimonials/results

**CTA Button**

**Money-Back Guarantee**

**Social Proof Badge**

**"What's Included" Section** - Repeated twice with slight variations

**Module Breakdown** - 6 modules with icons, titles, value statements, and descriptions

**Walkthrough Promise** - "PLUS, I'LL EVEN WALK YOU THROUGH THE EXACT FUNNEL..."

**CTA Button**

**Social Proof Badge**

**Detailed Playbook Preview** - "What's Waiting For You Inside" with specific page examples

**Bonuses Section** - "PLUS, JOIN TODAY AND YOU'LL ALSO GET:"

**Bonus #1** - With image, title, and value

**Bonus #2** - With image, title, and value

**Value Stack** - Total value, normal price, special price, savings amount

**CTA Button(s)**

**Security Badge** - "100% Secure 256-Bit Security Encryption"

**Modules Repeated** - Same 6 modules listed again

**CTA Button**

**Bonuses Repeated** - Same 2 bonuses

**Value Stack Repeated**

**Money-Back Guarantee Section** - Extended copy explaining guarantee with personal touch

**Final Assurance Statements**

---

## Based On: A system for creating repeatable revenue for coaches

### High-Level Structure:

**Program Name Header** - "REPEATABLE REVENUE OPERATING SYSTEM"

**Main Value Proposition Headline** - Calm, life-friendly system for consistent weekly sales

**Dual CTA Buttons** - Price visible in button + "START CREATING REPEATABLE REVENUE"

**Social Proof Subheadline** - "Join XXX+ [audience] who've traded [pain] for [gain]"

**Image/Graphic**

**Training Video Section** - "WATCH THE FULL TRAINING" with embedded long-form video (1:15:40)

**Section Headline** - "IT'S YOUR TIME"

**Main Section Headline** - "The monthly revenue reset cycle stops now"

**Empathy Copy Block** - Three paragraphs acknowledging their success and current struggles

**Problem Agitation** - Describing the revenue rollercoaster and burnout cycle

**Root Cause Identification** - "It's not because you're doing anything wrong" + explanation

**Solution Hint** - "You just need a system that bends when life does"

**Testimonial Quote** - Short format with name

**Section Headline** - "THE HIDDEN TRUTH"

**Main Section Headline** - "MOST online business MODELS WEREN'T BUILT to be life-friendly"

**Traditional Model Critique** - Detailed critique of launches, evergreen funnels, etc.

**Reframe Statement** - "It's not you; it's the models you were handed"

**CTA Buttons**

**Testimonial Quote** - Longer format with full name

**Section Headline** - "FINALLY"

**Main Section Headline** - "consistent revenue. no burnout. total freedom."

**Founder Story Copy Block** - Personal journey through various business models

**Solution Origin Story** - How they created the system

**Result Statement** - "It's how we stabilized our business, doubled our revenue, and cut our hours in half"

**Image/Graphic**

**Section Headline** - "INTRODUCING"

**Main Section Headline** - Product name

**Product Description** - Two-paragraph explanation of what it is and what you already have

**"Here's How It Works" List** - 4 numbered gateway elements with emoji numbers

**"Together, these four gateways..." Transition Statement**

**Image/Module Icon**

**Module #1 Headline** - "Live Mini Workshops"

**Module #1 Subheadline** - Benefit-focused tagline

**Module #1 Copy Block** - Detailed explanation of this gateway

**Module #1 Resources List** - "RESOURCES INSIDE RR:OS" with 4 checkmark items

**Image/Module Icon**

**Module #2 Headline** - "Workshop Replays"

**Module #2 Subheadline** - "EARN WHILE YOU REST"

**Module #2 Copy Block**

**Module #2 Resources List** - 4 checkmark items

**Image/Module Icon**

**Module #3 Headline** - "Existing Assets"

**Module #3 Subheadline** - "GOLD HIDING IN PLAIN SIGHT"

**Module #3 Copy Block**

**Module #3 Resources List** - 4 checkmark items

**Image/Module Icon**

**Module #4 Headline** - "Low-lift Upgrades"

**Module #4 Subheadline** - "EVERY SALE LEADS TO THE NEXT"

**Module #4 Copy Block**

**Module #4 Resources List** - 4 checkmark items

**Testimonial Quote** - Extended format with detailed feedback

**Image/Graphic**

**"What's Included" Section Headline**

**Checklist of Inclusions** - 7 main checkmark items (system, calendar, paths, resources, etc.)

**Gifts Subheadline** - "And to make sure nothing stands in your way..."

**Gift #1** - With checkmark

**Gift #2** - With checkmark

**Pay-In-Full Bonus** - With wizard emoji, description of AI GPTs

**Pricing Block** - "Today's Price: Just $X USD or X monthly installments of $X USD"

**Dual Pricing CTA Buttons** - "PAY IN FULL (BEST PRICE + GET BONUS)" and "PAY IN INSTALLMENTS"

**Disclaimer #1** - "Important: your results will vary" with detailed explanation

**Disclaimer #2** - "This purchase is non-refundable" with detailed explanation

**Section Headline** - "EVEN WHEN LIFE IS LIFING"

**Main Section Headline** - "THE SYSTEM KEEPS RUNNING"

**Copy Block** - Explanation of life-friendly design

**4-Item Checklist** - How each part keeps working

**Closing Statement** - "And the best time to start is not after..."

**Testimonial Quote**

**Section Headline** - "If this is what your business has started to feel like"

**6 Pain Point Statements** - Each with sad emoji

**Reflection Question** - "If that sounds familiar, ask yourself how many more months..."

**Contrast Headline** - "Here's what life on the other side of Repeatable Revenue feels like..."

**Vision Copy Block** - Five paragraphs of "day in the life" future pacing

**Invitation Statement** - "This is the freedom-first rhythm we built for ourselves"

**Testimonial Quote**

**Section Headline** - "EASIER EVERY MONTH"

**Main Section Headline** - "CONSISTENCY COMPOUNDS quickly"

**Month-by-Month Progression** - Three sections describing Month 1, Month 2, Month 3

**Final Vision Statement** - Bold summary of end state

**Testimonial Quote**

**Image/Graphic** - Repeated

**"What's Included" Section (Repeated)** - Same 7 items + gifts + bonus

**Pricing Block (Repeated)**

**Dual CTAs (Repeated)**

**Disclaimers (Repeated)**

**Section Headline** - "SEE INSIDE RR:OS"

**Main Section Headline** - "take a look around"

**Video Tour** - Shorter walkthrough video (5:15)

**CTA Buttons**

**Testimonial Quote**

**Section Headline** - "THERE'S MORE"

**Main Section Headline** - "We've got free gifts for you"

**Value Recap** - 4 checkmark items of what system has done for them

**Gifts Intro Copy** - "But hey, gifts are fun..."

**Gift #1 Headline** - "Vault of Workshops"

**Gift #1 Copy Block** - Explanation with value proposition

**Gift #1 Breakdown** - "Here's what you'll get instant access to" + 6 workshop titles with checkmarks

**Gift #2 Headline** - "2 Live Workshops"

**Gift #2 Copy Block** - Explanation and value

**CTA Buttons**

**Section Headline** - "PAY IN FULL BONUS"

**Main Section Headline** - "REPEATABLE REVENUE AI WIZARDS" with wizard emoji

**Bonus Introduction Copy** - Why they built these tools

**6 Wizard Descriptions** - Each with wizard emoji, name, and benefit

**CTA Buttons**

**Two Testimonial Quotes** - About the wizards specifically

**Image/Graphic** - Repeated

**"What's Included" Section (Repeated for 3rd time)**

**Pricing Block (Repeated for 3rd time)**

**Dual CTAs (Repeated)**

**Disclaimers (Repeated)**

---

## Based On: A course about creating and scaling low-ticket digital products

### High-Level Structure:

**Logo Header**

**Main Headline** - Two-line promise about launching and scaling low-ticket product

**Subheadline** - Long-form benefit list (No X, No Y, No Z... Build once, sell forever)

**Salutation** - "Dear Friend,"

**Opening Hook** - "If you wish you had..." desire statement leading to "good news"

**Credibility Statement** - Name introduction + what they're good at

**Proof Section** - "In fact, here's some stats..." + 5 product screenshot images

**Agitation** - "The crazy thing about all of these stats..." emphasizing low prices

**Bold Result Statement** - "Yet they've produced over six figures..."

**Curiosity Questions** - "You're probably wondering how? Why? What the hell..."

**Transition Statement** - "Well, you might not believe it, but..."

**Section Headline** - "Low ticket products = Big paydays"

**Traditional Model Critique** - Dream vs. reality of high-ticket courses

**Contrast/Reframe** - "But with low ticket products... These are my secret weapons"

**Three Bullet Benefits** - Why low-ticket works better

**Transition + CTA** - "Most importantly..." leading to "Show Me How" button

**Section Headline** - "Isn't it time you got paid for how smart you are?"

**Problem Agitation** - Cash flow rollercoaster, feast/famine cycle

**Solution Statement** - "You need to clone yourself by productizing your knowledge"

**Section Headline** - Bold statement about not needing lead magnet, need buyer magnet

**Lead Magnet Critique** - Why traditional lead magnets keep you on hard mode

**Reframe** - "Why not just live life on 'easy mode' instead?"

**Bold Statement** - "Low ticket products aren't lead magnets. They're BUYER magnets"

**Benefits List** - How buyer magnets change everything

**CTA Button** - "Show Me How"

**Section Headline** - "Low ticket = Big profit"

**Objection Handling** - Addressing "can't make money with low ticket" belief

**Personal Story** - "I used to think the same thing. But then I realized..."

**Proof Images** - 3 large order screenshots showing high cart values

**Two Bullet Benefits** - Easier to sell + more profitable

**Usage Description** - How to use them daily without launches

**Section Headline** - "Create once. Sell forever."

**14+ Bullet List** - Comprehensive benefits and reasons (impulse buys, easier to sell, more testimonials, affiliate-friendly, etc.)

**Transition** - "I can keep going, but I think you get the point"

**Three-Word Process** - "Launch it. Sell it. Scale it."

**Setup Copy** - You don't need to create anything, it's already done

**Product Introduction** - "Introducing... The Printing Press"

**Product Logo/Image**

**Product Description** - One-sentence promise with "copy my exact process" hook

**"Here's why you need this course:" Section** - Three paragraphs about printing money

**Bold Emotional Statement** - "Nothing quite feels as good as printing your own digital product money"

**Unique Delivery Mechanism** - "This is a course you're actually going to complete. Here's why..."

**Email Delivered Course Explanation** - Why this format works better

**CTA Button** - "Enroll Now →"

**"Here's What's Inside" Section Headline**

**Module Breakdown** - 7 modules, each with:
- Module number and name
- Brief description
- 3-4 bullet points of what's covered

**CTA Button** - "Enroll Now →"

**"Here's What Life Looks Like After..." Section Headline**

**10+ Future-Pacing Bullets** - Vivid scenarios of life with product

**CTA Button** - "Enroll Now →"

**"Here's Some Results..." Section Headline**

**Client Case Study #1** - Tanner Funk with testimonial screenshot

**Client Case Study #2** - Colin quote with results

**Disclaimer** - "Of course, this is the first time..." managing expectations

**Transition** - "Now, you're probably wondering..."

**"How much?" Section Headline**

**Price Anchoring** - Private coaching prices ($4,200, raised to $6,000)

**Price Reveal** - "It's only one payment of $297"

**Value Justification** - How quickly it pays for itself

**Personal Opinion** - "In my opinion, low ticket products are the answer"

**Money-Back Guarantee** - 30-Day, 100% headline + detailed explanation

**"Why You Need To Join Today" Section Headline**

**Scarcity** - Only opens a few times per year

**Pain of Inaction** - "Imagine how much money you'll miss out on..."

**Choice Framework** - Join and succeed OR stay stuck

**Bold Closing Statement** - "It's time you packaged up your expertise..."

**Final Instructions** - Email note about sign-up

**Order Form** - ThriveCart embed (currently showing "not available for sale")

---

## Based On: A workshop teaching how to speed up sales with simple shifts

### High-Level Structure:

**Rating Badge** - 4.9 from XXX ratings

**Workshop Cover Image**

**Value Proposition Headline** - Speed up sales in 2025 with 5 simple shifts

**Embedded Video** - Short preview video with sound control

**CTA Button** - Price visible ($27 USD)

**Three Emoji-Led Problem Statements** - Each with emoji, pain point question

**"Here's what we cover" Section Headline**

**9 Checkmark Bullets** - Specific outcomes and learnings from workshop

**CTA Button**

**Social Proof Headline** - "Inspired Action...in action"

**Supporting Copy** - What we share works right now in 2025

**Two Proof Images** - Results/stats graphics

**Disclaimer** - Italicized results disclaimer

**CTA Button**

**Image**

**Benefit Headline** - "Add these 5 ingredients to any offer..." with action-oriented outcome

**CTA Button**

**Social Proof Section** - "Hear directly from workshop buyers"

**Rating Badge (Repeated)**

**Filter Tab** - "All"

**Testimonial Grid** - 20+ testimonials with names and quotes, "LOAD MORE" button

**Founder Section** - "Hey! We're [Names]. 👋"

**Founder Photo**

**Credibility Statement** - Track record (100+ offers created)

**Vulnerability/Relatability** - "And they haven't all been bestsellers" with emojis

**Story Copy** - Journey of learning what works through trial and error

**Current Results** - What they do these days with the 5 ingredients

**Implementation Ease** - "The cool thing is..." quick-add nature of strategies

**FAQ Section** - "Got a question?"

**5 Q&A Pairs** - Each with question as subheadline and detailed answer

**CTA Button**

**Image (Repeated)**

**Main Headline (Repeated)** - Speed up sales variation

**CTA Button**

---

## Based On: A workshop with a plug-and-play 5-day sales campaign system

### High-Level Structure:

**Rating Badge** - 5.0 from XX ratings

**Workshop Cover Image**

**Value Proposition Headline** - Plug-and-play daily deals campaign bringing consistent sales for 5 days + leads to core offer

**Embedded Video** - With sound controls (Vidalytics player)

**CTA Button** - Price visible ($77 USD)

**Three Testimonial Quotes** - Short format with names

**Three Emoji-Led Problem Statements** - Old offers, holiday promos, complicated planning

**Transition Copy** - "If you're ready to bring sales..." with system promise

**Two Proof Images** - Results graphics

**CTA Button**

**Disclaimer** - Results will vary

**"What's Included" Section Headline**

**Icon/Image**

**9+ Checkmark Bullets** - Specific deliverables and outcomes

**Three Testimonial Quotes** - Mid-length with names

**Bold Statement** - "We hand over the whole roadmap" explaining the system value

**CTA Button**

**Three More Testimonial Quotes** - Repeated from above

**Three Bold Statements** - Flash sale appearance, strategic system, repeatable nature

**CTA Button**

**Three More Testimonial Quotes**

**Two Images**

**Headline** - "Give us 90 mins..." promise

**CTA Button**

**Testimonial Grid** - "All" filter tab + 20+ testimonials + "LOAD MORE"

**Founder Section** - "Hey! We're [Names]! 👋"

**Founder Photo**

**Track Record** - 100+ digital products in 5 years

**Problem/Solution Story** - Why they built the system

**Use Cases List** - 3 bullet points of what it's good for

**Best Part** - Light, simple, holiday-friendly

**Personal Examples** - Running it while offline (Thanksgiving, Italy trip)

**Value Statement** - Tested, repeatable campaign they actually run

**Two Images (Repeated)**

**Main Headline (Repeated)**

**CTA Button**

**Three Testimonial Quotes** - Longer format

**FAQ Section** - "Got a question?"

**9 Q&A Pairs** - Detailed questions and answers

**CTA Button**

---

## Based On: A low-ticket client acquisition system for service providers

### High-Level Structure:

**Warning Banner** - All caps target audience alert

**Logo**

**Disruptive Headline** - "Still Using [Old Method]? DITCH IT."

**Main Promise** - Switch to $5 'Launchpad' converting 10% to clients

**CTA Button** - With money-back guarantee note

**Four Proof Screenshots** - Client results with visible numbers

**Rating Badge** - 4.9/5 based on 1,204 purchases

**Problem Question** - "Are you selling a front end offer but nobody is upgrading?"

**Bold Reframe** - "IT'S NOT THAT... It's that..."

**Three-Step Breakdown** - What needs to happen for change (consume, implement, bridge gap)

**Problem Agitation** - Where it falls down (number 2 - implementation)

**Solution Tease** - "We've found a way..."

**Section Headline** - "HERE'S HOW IT WORKS..."

**Image**

**Three-Step Process** - Each with step number, description (Eight-Minute Authority VSL, $5 AI Launchpad, core offer sells speed)

**Simplification Statement** - No stacking/upsells needed

**Bold Closing** - "THAT'S IT."

**Transition Headline** - "READY TO GET STARTED?"

**Product Name + Promise** - Launchpad will build custom plan

**"Here's exactly what it will do" Intro**

**Four Bullet Benefits** - Each with outcome in italics + bold benefit + value amount

**"ALL IN LESS THAN 5 MINUTES" Statement**

**Bonuses Section** - "BONUSES: You'll Also Get..."

**Three Lightning Bolt Bonuses** - Each with emoji, bold name, description, value

**All Caps Summary** - "EVERYTHING YOU NEED..." with three-part promise

**CTA Button**

**Section Headline** - "THE $5 CLIENT ENGINE IN ACTION 👇"

**Proof Screenshot** - Typical day results

**Section Headline** - "OTHER DUDES RUNNING IT..."

**9 Client Case Studies** - Each with bold parenthetical result statement + screenshot

**Founder Section** - "I'm [Name], Founder of [Company]"

**Track Record** - 100+ campaigns built

**Vulnerability** - "And yeah... they haven't all been winners"

**Discovery Statement** - What works in 2025

**Core Insight** - If you can get buyer to believe + start implementing

**What Product Does** - "That's exactly what the $5 Client Engine does"

**Bold Statement** - "It's a simple system that:"

**Three Checkmark Benefits** - Brings in buyers, delivers AI plan, moves to premium

**Implementation Ease** - Plug in under a day, no new tech, start with $10/day

**Product Name Header** - Large headline format

**Product Description** - Get custom plan in 5 minutes

**CTA Button** - With money-back guarantee

**Logo (Small)**

**Copyright + Footer Links**

---

## Based On: A template pack of proven static ad creatives for e-commerce brands

### High-Level Structure:

**Note: This page has significant content repetition for emphasis**

**Bonus Banner** - Gift emoji + free bonus for ordering today

**Logo**

**Target Audience Statement** - "For Brands Ready To Tap Into..."

**Dual Headlines** - Repeated twice (13 winning templates + 11 BFCM bonus)

**Value Proposition Copy** - BFCM sales numbers + product description

**Product Image**

**Subheadline** - 24 templates, 10 minutes or less

**CTA Button** - With price and bonus callout

**Testimonial Quote** - 5 stars + name

**Social Proof Headline** - "TRUSTED XXX+ Shopify brands"

**Logo Grid** - 9 brand logos repeated multiple times in infinite scroll

**Lead Capture Form** - Name, phone, email, revenue dropdown

**Five Client Results** - Each with bold statement + screenshot

**Three Bold Headlines** - "$1 Each" repeated emphasis

**Product Description** - What was done (13 ads to 13 templates)

**Problem/Solution Copy Block**

**CTA Button**

**Benefit Headline** - "Make New Ads In Minutes..."

**Problem Agitation** - Time investment, uncertainty

**"So we solved it for you" Statement**

**Image**

**Three Checkmark Benefits**

**Implementation Steps**

**CTA Button**

**"Here's Exactly What You're Getting" Headline**

**Five Items List** - Each with checkmark, bold name, description, value amount

**Value Stack Breakdown**

**CTA Button**

**Differentiation Headline** - "This Is Different..."

**Competitor Critique** - Why other template packs are garbage

**Validation Process** - Three checkmark criteria

**CTA Button**

**Three Bold Headlines (Repeated)**

**Founder Section** - Name + Company + Credentials

**Track Record** - Clients, ad spend

**Core Principle** - "MAKE BETTER ADS"

**Three Benefit Breakdowns** - How creatives determine CAC, scale, growth

**Transition** - "But there's a problem..."

**Problem Headline** - "The REAL Reason Why You Can't Scale"

**Resource Comparison** - What they have vs what you don't

**Relatable Struggle** - What you do instead

**Failure Cycle** - Money burned, time wasted, stuck revenue

**Transition Questions** - "But what if you could skip..."

**Founder Section (Repeated)**

**Results Section** - "This Is What Success Looks Like..."

**Six Client Cases** - Each with statement + screenshot

**Six More Testimonial Screenshots**

**CTA Button**

**Money-Back Guarantee** - 100% headline + 30-day details

**FAQ Section** - 9 Q&A pairs

**Image**

**Closing Copy** - Stop gambling statement + product recap

**CTA Button**

**Logo (Repeated)**

**Facebook Disclaimer**

---

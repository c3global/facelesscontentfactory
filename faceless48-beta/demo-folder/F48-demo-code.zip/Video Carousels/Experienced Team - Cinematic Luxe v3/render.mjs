import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill} from '@remotion/renderer';
const browserExecutable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const serveUrl=await bundle({entryPoint:process.cwd()+'/entry.tsx',publicDir:process.cwd()+'/public'});
for (const id of ['Cover','Close','CrossClose']) {
  const composition=await selectComposition({serveUrl,id,browserExecutable});
  await renderStill({serveUrl,composition,browserExecutable,frame:id==='Cover'?0:150,output:'out/'+id+'.png'});
  await renderMedia({serveUrl,composition,browserExecutable,outputLocation:'out/'+id+'.mp4',codec:'h264',concurrency:1});
  console.log('READY '+id);
}

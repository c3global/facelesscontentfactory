import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Luxe} from './Luxe';
const variants = [{id:'Cover',slide:1},{id:'Close',slide:6},{id:'CrossClose',slide:6,crossPlatform:true}];
registerRoot(() => <>{variants.map(({id,...props}) => <Composition key={id} id={id} component={Luxe} defaultProps={props} durationInFrames={300} fps={30} width={1080} height={1350}/>)}</>);

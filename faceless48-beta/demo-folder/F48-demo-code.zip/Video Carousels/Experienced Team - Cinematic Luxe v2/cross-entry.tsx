import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Luxe} from './CrossLuxe';
registerRoot(() => <Composition id="CrossClose" component={Luxe} defaultProps={{slide:6}} durationInFrames={300} fps={30} width={1080} height={1350}/>);

import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia} from '@remotion/renderer';
const browserExecutable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const serveUrl=await bundle({entryPoint:process.cwd()+'/cross-entry.tsx',publicDir:process.cwd()+'/public'});
const composition=await selectComposition({serveUrl,id:'CrossClose',browserExecutable});
await renderMedia({serveUrl,composition,browserExecutable,outputLocation:'out/Cinematic Luxe - cross close.mp4',codec:'h264',concurrency:1});

# The Second Checklist: video carousel storyboard

> REJECTED DRAFT, November 5, 2026. Preserved for history. Do not render these slide plans. See `03-studio-asset-handoff.md` for the user correction and imported source assets.

Prepared for Dr. CK on Thursday, November 5, 2026. Version 1, for storyboard review.

This is one swipeable Instagram carousel containing seven individual video files. The proposed duration is 60 seconds across all seven files. Each slide starts with readable text, develops one visual idea, and holds its complete message. It works muted. A combined video would be a separate adaptation for other channels.

The first concept moves from November 8 to November 5 at Dr. CK's explicit direction. No posting time has been changed in an external system. The 5:53 PM ET time in Claudeyo's handoff remains a proposed secondary slot. Nothing in this package is scheduled or published.

## Creative direction

A premium investigation told through moving evidence: a dashboard, a paper form, a workflow, and a blank signature line. The opening raises unease, the evidence explains it, and the final slides make it useful to a leader reviewing a rollout.

Use C3 crimson #C91B19, black #000000, white #FFFFFF, copper #A9574A and highlight #F1B9A5. Use DM Sans for clear, bold statements and Playfair Display italic for selected words. Keep metallic effects restrained. Use readable containers, generous space, fine rules, and large evidence details. Avoid miniature dashboards and long typed paragraphs.

The current storyboard uses original motion graphics. It requires no new stock, character generation, voiceover, or paid generation. CiCi is named as the practitioner in the existing Patient File, with no new portrait substituted for her approved identity. This is a companion to that story, rather than a replacement for its cinematic episode.

## Reference review: what was actually observed

Source links supplied by Dr. CK:

- https://www.instagram.com/p/De8I3VcjtKq/
- https://www.instagram.com/p/DfI_L5VDohx/
- https://www.instagram.com/p/DfGcYAkmuri/
- https://www.instagram.com/p/De2-09Cjnyx/

Direct web retrieval failed for all four posts. The authenticated Chrome tab allowed inspection of the fourth post at img_index=4. That visible frame used textured black, a bold white headline, warm metallic italic serif emphasis, a rounded translucent chart card, a row-and-column proof grid, a small page number, and a swipe control. The four video elements then present in the page reported approximately 15 seconds each. That does not establish every slide's runtime.

Browser control was subsequently interrupted. Only the one visible frame was visually inspected. The full slide sequences, entrances, transitions, soundtrack, and the other three posts have not been verified. This is an original C3 proposal informed by that limited observation and the supplied handoff, rather than a completed comparative audit of all four references.

Transfer the clear hierarchy, visual evidence, restrained metallic emphasis, and readable card system. Keep the source creator's claims, scores, offer, wording, and branding out of C3's execution. The storyboard's timing and motion below are proposed creative decisions.

## Seven-slide breakdown

### 1. The hook, 8 seconds

**Exact primary text:**

How do you know if your new AI tool is really working?

**Supporting text:**

The dashboard says yes. Someone's still doing the old checklist.

**Visual:** A clean dashboard sits behind a paper checklist. The two artifacts overlap so that the duplicate process is visible at once. The paper partly covers the dashboard without covering its meaning.

**Motion:** Keep the headline readable from the opening frame. The dashboard rises 22 pixels over 0.55 seconds. The paper has a small, slow drift. Hold the resolved layout through the end. Emphasize “really working?” in copper serif.

**Job:** Establish the AI rollout topic immediately and make the second process intriguing. The lower edge invites the viewer to continue the investigation.

### 2. The clue, 8 seconds

**Exact primary text:**

The tool finished. The clerk kept working.

**Supporting text:**

In The Second Checklist, a clerk runs the AI review. Then he fills out the paper form.

**Graphic text:**

The AI review is complete.

The work continues.

The paper checklist still needs a signature.

**Closing text:** The new tool added another step.

**Visual:** Two connected workflow cards. The top card carries a completed review check. A copper connector leads to the crimson paper-form card below.

**Motion:** Reveal the connected cards together in a short, contained entrance. Keep all text visible for the reading hold. The work flow is the story; decorative motion stays secondary.

**Job:** Show what duplicate work looks like. Name the Patient File so the scene is understood as part of C3's series, without presenting it as client evidence.

### 3. The investigator's question, 7 seconds

**Exact primary text:**

What did the tool replace?

**Supporting text:**

CiCi watches the work. Then she asks what changed.

In this Patient File, the old checklist stayed.

**Visual:** Oversized question on black. A single inquiry card sits beneath it. Use the page's open space as a deliberate pause after the dense workflow.

**Motion:** The question is present at the opening. Bring the observation card in over 0.55 seconds, beginning at 0.35 seconds. Hold the answer beneath it.

**Job:** Model observation and inquiry before diagnosis. The question leads to an artifact that can be examined.

### 4. The reveal, 8 seconds

**Exact primary text:**

The old form was still required.

**Supporting text:**

The order that would end it was unsigned.

**Evidence text:**

This form ends when the director signs the order.

Director's signature.

The signature line is blank.

**Visual:** A large paper document with a blank signature line. A crimson ellipse identifies the missing signature. This is a graphic representation of the instruction in the Patient File script, rather than a fabricated screenshot of a real organization.

**Motion:** The document settles into position. Draw the ellipse over roughly 0.55 seconds, then hold. Keep the blank line empty. Do not imply that CiCi signs or has authority to retire the form.

**Job:** Pay off the investigation with a specific, visible decision. No performance statistics are needed.

### 5. The meaning, 9 seconds

**Exact primary text:**

A second checklist can reveal an unfinished decision.

**Supporting text:**

Ask what the paper still protects before deciding it can go.

**Three cards:**

1. It may preserve a required record.
2. It may keep approval with a named person.
3. It may feel safer to the people responsible.

**Visual:** Three copper-edged evidence cards, each carrying one possible reason that the parallel process persists.

**Motion:** Stagger the card entrances by 0.2 seconds. The final card is fully visible by about 1.1 seconds, leaving nearly eight seconds to read.

**Job:** Add the human and organizational stakes. Present possible explanations without assuming the paper is unnecessary or that more training will resolve the problem.

### 6. The useful takeaway, 12 seconds

**Exact primary text:**

Ask three questions.

**Context label:** Bring this to your next rollout review.

**Three questions:**

1. What work did the new tool replace?
2. Who can authorize the old step to end?
3. What must stay protected when it does?

**Closing text:** A green dashboard can miss the extra work.

**Visual:** Three large numbered question cards. This is the practical frame a viewer can pause on or capture.

**Motion:** Short staggered entrances, with every question fully visible by about 1.1 seconds. Keep the layout still for the remaining reading time. Do not animate the words individually.

**Job:** Give the buyer a concrete exercise while leaving the fuller readiness work to the assessment.

### 7. The next step, 8 seconds

**Exact primary text:**

How ready is your team for the change?

**CTA:**

Comment SHIFT and I'll send you the readiness index.

**Supporting text:**

The Shift Index is C3 Global's readiness assessment.

**Visual:** A crimson card with the word SHIFT in large copper type. Keep the same evidence-card styling used through the investigation.

**Motion:** A short card entrance, then a stable reading hold. Avoid a fake comment interface, invented engagement, countdowns, or additional asks.

**Job:** Route change-readiness interest to the Shift Index. There is one primary conversion action.

## Instagram caption draft

Template: Hooks & Caption Starters, Page 1, #20, “Can you explain THIS to me? (start story...)”. Carousel hook: Page 3, #20, the approved handoff's investigator direction. Structure: clue, inquiry, artifact reveal, possible explanations, three-question review, keyword CTA. Close: CTA & Keyword System, SHIFT wording already attached to Patient File #003. Emotion: uneasy, progressing toward curiosity and practical agency.

Can you explain this to me? A clerk finishes the AI review, then reaches for the paper checklist. 👀

That's the moment to watch in The Second Checklist. The old form still needs a director's signed order before it can end. The tool has been added, and the paperwork is still required.

If you lead a team that's using new AI software while keeping the old process running, that can feel discouraging. Your dashboard may show the rollout moving ahead while the people doing the work are carrying an extra step.

At your next rollout review, ask what work the new tool replaced. That question can bring an unfinished approval or a required record into the conversation before you decide what to change. 🔎

Comment SHIFT and I'll send you the readiness index.

#AIAdoption #OrganizationalChange #C3Global

## Commercial path

- Buyer: a leader responsible for an institutional or organizational AI rollout.
- Pain: the dashboard appears healthy while staff continue the old workflow alongside the new tool.
- Offer and destination: C3 Global's Shift Index, https://www.c3global.co/shiftindex.
- Mechanism: Instagram comment keyword SHIFT, with the approved readiness-index wording.
- Conversion event: Shift Index submitted.
- Follow-up: assessment results and the existing nurture workflow. Preserve source and keyword attribution according to the CTA & Keyword System.
- The system documents this route. This session has not tested the live comment automation or submitted the assessment. Live delivery remains a prepublication check.

## Production and review

- Canvas: proposed 1080 x 1350, 4:5, 30 fps. This matches the shape of the observed reference frame. Verify channel acceptance during the publishing step.
- Deliverable after storyboard approval: seven H.264 MP4s in numbered order. One file per swipe. Do not publish the master storyboard timeline as the carousel file.
- Audio: no narration required. The draft is designed to work muted. Any licensed music or sound design is a later editorial choice, not an assumed asset.
- Safe layout: content stays approximately 76 pixels inside each side; header and footer stay separate from the argument and evidence.
- Type: DM Sans and Playfair Display, bundled locally. Primary statements roughly 72 to 92 pixels, body copy mostly 28 to 35 pixels, ancillary labels 18 to 24 pixels. Inspect at phone size.
- Motion: meaningful entrances followed by generous holds. The first frame contains the main statement. Each slide can be understood independently and does not require precisely timed swiping.
- No generated statistics, customer quotes, results, vendor logos, or new characters.
- This carousel uses the checklist investigation without revealing the episode's separate page-three cliffhanger. The cinematic script remains its own deliverable.
- All scripts and production changes are in the new Video Carousels project. The installed Faceless48 Creator package and the existing Clinic Notes project are preserved.

The plugin's existing lint checks target talking-head effects and do not inspect carousel layout. A clean generic lint result is therefore not evidence that every carousel text box fits. Use schema validation, TypeScript checks, actual rendered stills, and visual inspection for this draft. Motion and audio cannot be approved from stills alone.

## Faceless48 project handoff

The customer project is `F48 Project/` beside this file. `src/Carousel.tsx` supplies the seven motion layouts, registered as the Carousel composition in the customer project. The local `f48` command supports the carousel plan and its seven storyboard moments. This is a project-specific extension, not an update to the distributed plugin.

Review command:

```sh
npm run f48 -- storyboard content/second-checklist-storyboard.json
```

After approval, render the seven independent slide plans:

```sh
npm run f48 -- batch content/second-checklist-jobs.json
```

This environment reuses the installed dependencies from the existing Clinic Notes project through a local link. On another computer, run `npm ci` in this project to install its pinned dependencies. If Remotion's supported headless browser is absent, set REMOTION_BROWSER_EXECUTABLE to an installed compatible Chrome executable or run Remotion's browser installer.

## Sources and decisions

- [Patient File #003, current working script v1.2](https://app.notion.com/p/408d063485968169a9e4de3af6422eca). Its page labels the script as awaiting Dr. CK; it is a source for this proposed companion carousel, not a newly claimed approved client case.
- [Patient File Content Library row](https://app.notion.com/p/3f9d06348596813aba28e29de1afe4f8), including the pain, SHIFT wording, destination, conversion event, and existing follow-up path.
- [CTA & Keyword System](https://app.notion.com/p/3d8d0634859681ec9386ea2ea2d9670e).
- [Copy Rules](https://app.notion.com/p/3edd06348596813f9a3ae03e45f69da4), including the November 3 caption standard.
- [Hooks & Caption Starters](https://app.notion.com/p/3edd063485968167a3f9d3d499274a05).
- [November campaign plan](https://app.notion.com/p/3ffd063485968125834ac6f1692f5d83). The page confirms Thursday-to-Wednesday weeks and calls parts of its proposed rhythm unresolved. Do not treat that page as proof of current publishing completion.
- Dr. CK's pasted handoff supplies the eight approved concept directions and today's priority. Week 6 is November 5 to 11; moving this carousel to today follows her latest instruction.
- Local saved C3 brand profile and C3 Creative Scout standards supply colors, typography, practitioner stance, and character continuity rules.

The Copy Rules prohibit invented client stories. This draft identifies the Patient File as the source of its story and introduces no customer testimony or new case facts. Editorial copy received two text reviews for clear language, source fidelity, one CTA, qualified interpretations, and complete sentences. Actual motion playback and live CTA delivery remain unverified at storyboard stage.

## Remaining concepts from the supplied handoff

The remaining seven are retained as a queue, with dates shown as inherited proposals. This package develops only the first concept. It does not silently reschedule the campaign.

| Priority | Concept | Proposed date from handoff | Slides | Keyword |
|---|---|---|---|---|
| 1 | Investigator: The Second Checklist | Nov 5, moved by Dr. CK | 7 | SHIFT |
| 2 | Experienced team members and the AI rollout | Nov 11 | 6 | AIREADY |
| 3 | News: integration and adoption | Nov 12 | 6 | AIREADY |
| 4 | Contrarian: calling workarounds resistance | Nov 16 | 7 | SHIFT |
| 5 | Four questions before trusting a green report | Nov 19 | 6 | SHIFT |
| 6 | Behind the build: the Dr. CiCi experiment | Nov 22 | 6 to 8 | Follow ask, per handoff |
| 7 | Thanking someone in front of the team | Nov 26 | 7 | CQ |
| 8 | Follow-up overload and AuthorityOS | Nov 28 | 6 | AUTHORITY |

The news and contrarian statistics in the handoff have not been verified in this session and are not repeated as facts in the first carousel. The experimenter piece still needs Dr. CK's real lessons before scripting.

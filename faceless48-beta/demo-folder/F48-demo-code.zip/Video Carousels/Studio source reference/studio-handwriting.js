// Handwriting choices are bundled locally. Licorice replaces the retired original font.
const HANDWRITING_FONTS=['Licorice','Swanky and Moo Moo','Patrick Hand SC','Homemade Apple','Indie Flower','Covered By Your Grace','Nanum Pen Script','Just Another Hand','Caveat','Neucha'];
function styleHandwriting(node,font){[node,...node.querySelectorAll('*')].forEach(e=>{e.style.fontFamily='"'+font+'"';e.dataset.customFont='true';e.dataset.handFont=font})}
function handFontHTML(html,font){const t=document.createElement('template');t.innerHTML=html;t.content.querySelectorAll('[data-edit].hand').forEach(e=>styleHandwriting(e,font));return t.innerHTML}
function applyHandwriting(scope){const font=$('handFont').value;if(!HANDWRITING_FONTS.includes(font))return;stopPreview();
 if(scope==='selected'){const list=chosenObjects().filter(e=>e.hasAttribute('data-edit')&&e.classList.contains('hand'));if(!list.length){toast('Select a handwritten note, such as Start with the question');return}list.forEach(e=>styleHandwriting(e,font));commit();toast(font+' applied to selected handwritten notes');return}
 commit();const p=project(),list=scope==='project'?p.slides:[p.slides[current]];
 for(const s of list){s.base=handFontHTML(s.base,font);for(const key in s.variants)s.variants[key]=handFontHTML(s.variants[key],font)}
 if(scope==='project')p.handFont=font;const i=current;current=-1;save();openSlide(i);$('handFont').value=font;updateHandwritingPreview();toast(font+' applied to handwritten notes '+(scope==='project'?'throughout this carousel':'on this slide'));
}
function updateHandwritingPreview(){$('handFontPreview').style.fontFamily='"'+$('handFont').value+'"'}
const handwritingStage=stageHTML;
stageHTML=function(s,f=format(),key=project()?.format){let html=retireHandwritingHTML(handwritingStage(s,f,key));const font=project()?.handFont==='Handlee'?'Licorice':project()?.handFont;if(!font)return html;const t=document.createElement('template');t.innerHTML=html;t.content.querySelectorAll('[data-edit].hand:not([data-hand-font])').forEach(e=>styleHandwriting(e,font));return t.innerHTML};
const handwritingOpen=openSlide;
openSlide=function(i){handwritingOpen(i);if(current<0)return;const family=$('canvasViewport').querySelector('.hand')?.dataset.handFont||project().handFont||'Licorice';
 $('editNotes').insertAdjacentHTML('afterbegin',`<details open><summary>Handwritten font</summary><p>Choose a style for handwritten notes. Headlines and body fonts stay as they are.</p><label>Handwritten style<select id="handFont"><optgroup label="Your favorites">${HANDWRITING_FONTS.slice(0,6).map(f=>`<option value="${f}">${f}</option>`).join('')}</optgroup><optgroup label="More from your list">${HANDWRITING_FONTS.slice(6).map(f=>`<option value="${f}">${f}</option>`).join('')}</optgroup></select></label><div id="handFontPreview" class="hand-font-preview">Start with the question.</div><button id="handFontSelected">Apply to selected handwritten notes</button><button id="handFontSlide">Apply to this slide’s handwritten notes</button><button id="handFontProject">Use throughout this carousel</button></details>`);
 $('handFont').value=family;$('handFont').onchange=updateHandwritingPreview;$('handFontSelected').onclick=()=>applyHandwriting('selected');$('handFontSlide').onclick=()=>applyHandwriting('slide');$('handFontProject').onclick=()=>applyHandwriting('project');updateHandwritingPreview();
};

function retireHandwritingHTML(html){
 if(!/Handlee/i.test(html))return html;
 const t=document.createElement('template');t.innerHTML=html;
 t.content.querySelectorAll('.hand,[data-hand-font]').forEach(e=>{
  if(e.dataset.handFont?.toLowerCase()==='handlee'||/\bHandlee\b/i.test(e.style.fontFamily))styleHandwriting(e,'Licorice');
 });return t.innerHTML;
}
const handwritingInit=init;
init=async function(){await handwritingInit();let changed=false;
 for(const p of state.projects){
  if(p.handFont?.toLowerCase()==='handlee'){p.handFont='Licorice';changed=true}
  for(const s of p.slides){const base=retireHandwritingHTML(s.base);if(base!==s.base){s.base=base;changed=true}
   for(const key in s.variants){const html=retireHandwritingHTML(s.variants[key]);if(html!==s.variants[key]){s.variants[key]=html;changed=true}}
  }
 }
 if(changed){save();renderProject()}
};

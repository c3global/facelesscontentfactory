// Text wrapping and object dimensions belong to each saved format layout.
// Keep the legacy collection intact; store edits separately to avoid cloning every
// historical portrait and slide on each keystroke. Downloaded backups stay complete.
const editedProjectQueue=new Map();
let projectStoreReady=false,projectStoreHasBaseline=false,savedAssetSignature='';
function assetSignature(){return state.assets.map(a=>[a.id,a.name,a.src?.length||0].join(':')).join('|')}
function readStudioKey(key){return new Promise((resolve,reject)=>{const r=db.transaction('studio').objectStore('studio').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function loadProjectEdits(legacyExists){
 const session=await readStudioKey('project-index-v4');
 if(session?.version===4){
  const edits=await Promise.all(session.order.map(id=>readStudioKey('project-edit-v4:'+id))),byId=new Map(state.projects.map(p=>[p.id,p]));
  edits.filter(Boolean).forEach(p=>byId.set(p.id,p));
  const order=[...session.order,...state.projects.map(p=>p.id).filter(id=>!session.order.includes(id))];state.projects=order.map(id=>byId.get(id)).filter(Boolean);
  if(byId.has(session.active))state.active=session.active;
  const assets=await readStudioKey('project-assets-v4');if(Array.isArray(assets)){const map=new Map(state.assets.map(a=>[a.id,a]));assets.forEach(a=>map.set(a.id,a));state.assets=[...map.values()]}
 }
 projectStoreReady=true;projectStoreHasBaseline=legacyExists||session?.version===4;savedAssetSignature=assetSignature();
}
save=function(){
 clearTimeout(saveTimer);const p=project();if(p)editedProjectQueue.set(p.id,p);$('saveState').textContent='Saving…';
 saveTimer=setTimeout(async()=>{
  const writes=new Map(editedProjectQueue);editedProjectQueue.clear();
  try{
   if(!db)throw Error('Browser storage unavailable');
   if(!projectStoreHasBaseline)state.projects.forEach(p=>writes.set(p.id,p));
   const signature=assetSignature(),saveAssets=!projectStoreHasBaseline||signature!==savedAssetSignature;
   await new Promise((resolve,reject)=>{const tx=db.transaction('studio','readwrite'),store=tx.objectStore('studio');
    writes.forEach((p,id)=>store.put(p,'project-edit-v4:'+id));
    store.put({version:4,active:state.active,order:state.projects.map(p=>p.id)},'project-index-v4');if(saveAssets)store.put(state.assets,'project-assets-v4');
    tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Save interrupted'));
   });projectStoreHasBaseline=true;savedAssetSignature=signature;$('saveState').textContent=editedProjectQueue.size?'Saving…':'Saved in this browser';
  }catch(e){writes.forEach((p,id)=>{if(!editedProjectQueue.has(id))editedProjectQueue.set(id,p)});$('saveState').textContent='Download project to save a portable backup';toast('Browser save unavailable. Use Download project or Save edited studio.')}
 },700);
};
const projectStoreInit=init;
init=async function(){await projectStoreInit();if(!projectStoreReady){projectStoreReady=true;projectStoreHasBaseline=false;state.projects.forEach(p=>editedProjectQueue.set(p.id,p));save()}};
function geometryText(e){return !!e?.hasAttribute('data-edit')}
function geometryShape(e){return !!e?.matches('svg.arrow,.line,.circle,.box')}
function geometryImage(e){return !!e?.matches('img,.photo')}
function geometryObject(e){return geometryText(e)||geometryShape(e)||geometryImage(e)}
function geometryNumber(e,key){return parseFloat(getComputedStyle(e)[key])||0}
function geometryRotation(e){return parseFloat(e?.style.rotate)||parseFloat(e?.dataset.rotation)||0}
function clearResizeFrame(){const v=$('canvasViewport');v?.querySelector('[data-resize-frame]')?.remove();v?.querySelectorAll('.geometry-framed').forEach(e=>e.classList.remove('geometry-framed'))}
function refreshResizeFrame(){
 clearResizeFrame();
 if(current<0||!selected||!geometryObject(selected))return;
 const stage=$('canvasViewport').querySelector('.stage'),a=stage.querySelector('.slide');
 if(!selected.isConnected)return;
 selected.classList.add('geometry-framed');
 const r=stage.getBoundingClientRect(),b=selected.getBoundingClientRect(),scale=r.width/parseFloat(stage.style.width);
 if(!scale)return;
 const size=24/scale;
 const frame=document.createElement('div');frame.dataset.resizeFrame='true';frame.setAttribute('aria-hidden','true');
 frame.style.cssText=`position:absolute;left:${(b.left-r.left)/scale}px;top:${(b.top-r.top)/scale}px;width:${b.width/scale}px;height:${b.height/scale}px;border:${1/scale}px solid #D48A8C;pointer-events:none;z-index:85;box-sizing:border-box`;
 for(const axis of geometryText(selected)?['width']:geometryImage(selected)?['both']:['width','height','both']){
  const handle=document.createElement('span');
  handle.title=axis==='width'?'Drag to change width':axis==='height'?'Drag to change height':'Drag to resize';
  handle.style.cssText=`position:absolute;width:${size}px;height:${size}px;border:${2/scale}px solid white;border-radius:50%;background:#a44328;pointer-events:auto;touch-action:none;box-sizing:border-box;cursor:${axis==='width'?'ew-resize':axis==='height'?'ns-resize':'nwse-resize'};right:${axis==='height'?`calc(50% - ${size/2}px)`:-size/2+'px'};bottom:${axis==='width'?`calc(50% - ${size/2}px)`:-size/2+'px'}`;
  handle.onpointerdown=event=>{
   event.preventDefault();event.stopPropagation();stopPreview();const object=selected,startX=event.clientX,startY=event.clientY,w=geometryNumber(object,'width'),h=geometryNumber(object,'height'),unit=a.getBoundingClientRect().width/1080;
   handle.setPointerCapture(event.pointerId);
   handle.onpointermove=e=>{if(geometryImage(object)){const dx=(e.clientX-startX)/unit,dy=(e.clientY-startY)/unit,change=Math.abs(dx)>=Math.abs(dy)?dx:dy*w/Math.max(1,h);setObjectDimension(object,'width',Math.max(20,w+change))}else{if(axis!=='height')setObjectDimension(object,'width',Math.max(20,w+(e.clientX-startX)/unit));if(axis!=='width')setObjectDimension(object,'height',Math.max(8,h+(e.clientY-startY)/unit))}const now=object.getBoundingClientRect();frame.style.width=now.width/scale+'px';frame.style.height=now.height/scale+'px';syncGeometryControls(false)};
   const finish=()=>{handle.onpointermove=null;commit();syncGeometryControls()};handle.onpointerup=finish;handle.onpointercancel=finish;
  };frame.append(handle);
 }
 if(geometryObject(selected)){
  const rotate=document.createElement('span');rotate.dataset.rotateHandle='true';rotate.title='Drag to rotate text';rotate.setAttribute('aria-label','Drag to rotate text');
  rotate.style.cssText=`position:absolute;width:${size/1.15}px;height:${size/1.15}px;border:${2/scale}px solid white;border-radius:50%;background:#a44328;pointer-events:auto;touch-action:none;box-sizing:border-box;cursor:grab;left:calc(50% - ${size/2.3}px);top:-${size*1.8}px`;
  const stem=document.createElement('span');stem.style.cssText=`position:absolute;left:50%;top:${size/1.15}px;height:${size*.8}px;border-left:${1.5/scale}px solid #D48A8C;pointer-events:none`;rotate.append(stem);
  rotate.onpointerdown=event=>{event.preventDefault();event.stopPropagation();stopPreview();const object=selected,rect=object.getBoundingClientRect(),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2,initial=Math.atan2(event.clientY-cy,event.clientX-cx),base=geometryRotation(object);rotate.setPointerCapture(event.pointerId);rotate.onpointermove=e=>{const angle=Math.atan2(e.clientY-cy,e.clientX-cx);object.style.rotate=`${Math.round(base+(angle-initial)*180/Math.PI)}deg`;const b=object.getBoundingClientRect();frame.style.left=(b.left-r.left)/scale+'px';frame.style.top=(b.top-r.top)/scale+'px';frame.style.width=b.width/scale+'px';frame.style.height=b.height/scale+'px';syncGeometryControls(false)};const finish=()=>{rotate.onpointermove=null;commit();syncGeometryControls()};rotate.onpointerup=finish;rotate.onpointercancel=finish};frame.append(rotate);
 }
 stage.append(frame);
}
function setObjectDimension(e,key,value){
 if(geometryText(e)){e.style.overflow='visible';e.style.height='auto'}
 if(geometryImage(e)){const prior=geometryNumber(e,key),other=key==='width'?'height':'width',otherPrior=geometryNumber(e,other);if(prior>0&&otherPrior>0)e.style[other]=Math.round(otherPrior*(value/prior))+'px'}
 e.style[key]=Math.round(value)+'px';
 if(e.matches('svg')){e.setAttribute('preserveAspectRatio','none');e.querySelectorAll('path,line,polyline,polygon,circle,ellipse').forEach(p=>p.setAttribute('vector-effect','non-scaling-stroke'))}
}
function syncGeometryControls(redraw=true){
 if(!$('objectWidth'))return;const e=selected,text=geometryText(e),shape=geometryShape(e);
 $('geometrySelection').textContent=text?'Text box selected':shape?'Arrow or shape selected':'Select a text block, arrow or shape.';
 for(const id of ['objectWidth','objectHeight','boxFontSize','boxRotation','boxLineHeight','boxAlignment','boxWrap','oneTextLine','arrowStroke'])$(id).disabled=!(id==='objectWidth'?(text||shape):id==='objectHeight'?shape:id==='arrowStroke'?e?.matches('svg.arrow,.line'):id==='boxRotation'?(text||shape):text);
 if(text||shape){$('objectWidth').value=Math.round(geometryNumber(e,'width'));$('objectHeight').value=Math.round(geometryNumber(e,'height'))}
 if(text){const css=getComputedStyle(e);$('boxFontSize').value=Math.round(parseFloat(css.fontSize));$('boxLineHeight').value=(parseFloat(css.lineHeight)/parseFloat(css.fontSize)||1.1).toFixed(2);$('boxAlignment').value=css.textAlign==='center'?'center':css.textAlign==='right'?'right':'left';$('boxWrap').value=css.whiteSpace==='nowrap'?'nowrap':'normal'}
 if(text||shape)$('boxRotation').value=Math.round(geometryRotation(e));
 if(e?.matches('svg.arrow'))$('arrowStroke').value=parseFloat(getComputedStyle(e.querySelector('path,line,polyline')||e).strokeWidth)||3;
 if(e?.matches('.line'))$('arrowStroke').value=Math.max(1,geometryNumber(e,'height'));
 if(redraw)refreshResizeFrame();
}
function oneTextLine(){
 if(!geometryText(selected))return;stopPreview();
 selected.querySelectorAll('br').forEach(e=>e.replaceWith(document.createTextNode(' ')));
 selected.querySelectorAll('div,p').forEach(e=>{e.append(document.createTextNode(' '));e.style.display='inline'});
 selected.style.whiteSpace='nowrap';selected.style.height='auto';
 const width=Math.ceil(Math.max(...[...selected.childNodes].map(n=>{const r=document.createRange();r.selectNode(n);return r.getBoundingClientRect().width/(selected.closest('.slide').getBoundingClientRect().width/1080)}),0));
 const measure=selected.cloneNode(true);measure.removeAttribute('data-object');measure.removeAttribute('id');measure.style.cssText+=';width:max-content;max-width:none;visibility:hidden;transform:none;translate:none;position:absolute';selected.parentElement.append(measure);const natural=measure.offsetWidth;measure.remove();
 const needed=Math.max(40,natural+6,width),left=geometryNumber(selected,'left')+(+selected.dataset.dx||0),margin=65;
 if(needed<=950&&left+needed>1015){selected.style.left=margin+'px';selected.dataset.dx='0';selected.style.translate=`0px ${selected.dataset.dy||0}px`}
 setObjectDimension(selected,'width',Math.max(needed,Math.min(950,geometryNumber(selected,'width'))));commit();syncGeometryControls();
 toast(needed>950?'One line set. This phrase is wider than the safe area; shorten it or reduce its size.':'One line set. Font size and emphasis kept.');
}
const geometrySelect=selectObject;
selectObject=function(e){geometrySelect(e);if(geometryText(e)){let changed=false;if(e.style.height!=='auto'){e.style.height='auto';changed=true}if(e.style.overflow!=='visible'){e.style.overflow='visible';changed=true}const css=getComputedStyle(e),font=parseFloat(css.fontSize)||40,line=parseFloat(css.lineHeight)||font,min=e.classList.contains('hand')?1.22:1.08;if(line<font*min){e.style.lineHeight=String(min);changed=true}if(changed)commit()}syncGeometryControls()};
const geometryCommit=commit;
commit=function(){geometryCommit();refreshResizeFrame()};
const geometryStage=stageHTML;
stageHTML=function(s,f=format(),key=project()?.format){
 const t=document.createElement('template');t.innerHTML=geometryStage(s,f,key);
 t.content.querySelectorAll('[data-edit]').forEach(e=>{const font=HANDWRITING_FONTS.find(font=>e.style.fontFamily.replace(/["']/g,'').toLowerCase().includes(font.toLowerCase()));if(font&&!e.classList.contains('hand')){e.classList.add('hand');if(!e.dataset.handFont)styleHandwriting(e,project()?.handFont||font)}});
 return t.innerHTML;
};
const geometryOpen=openSlide;
openSlide=function(i){
 geometryOpen(i);if(current<0)return;
 $('editNotes').insertAdjacentHTML('afterbegin',`<details open id="objectGeometry"><summary>Text box & arrow size</summary><p id="geometrySelection">Select a text block, arrow or shape.</p><label>Box width / arrow length (px)<input id="objectWidth" type="number" min="20" max="2200" step="10" disabled></label><label>Object height (px)<input id="objectHeight" type="number" min="8" max="2200" step="10" disabled></label><label>Text size (px)<input id="boxFontSize" type="number" min="12" max="360" step="1" disabled></label><label>Object rotation (degrees)<input id="boxRotation" type="number" min="-180" max="180" step="1" disabled></label><label>Line spacing<input id="boxLineHeight" type="number" min=".7" max="3" step=".05" disabled></label><label>Text alignment<select id="boxAlignment" disabled><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select></label><label>Text wrapping<select id="boxWrap" disabled><option value="normal">Wrap to box width</option><option value="nowrap">Keep on one line</option></select></label><button id="oneTextLine" disabled>Put text on one line</button><label>Arrow / line thickness (px)<input id="arrowStroke" type="number" min="1" max="24" step=".5" disabled></label><p>Drag copper handles to resize or rotate. Text boxes grow to fit their lines; width changes wrapping without changing font size. The outline and handles are editor guides and never export.</p></details>`);
 for(const [id,key] of [['objectWidth','width'],['objectHeight','height']])$(id).oninput=()=>{if(!geometryObject(selected))return;const value=Number($(id).value);if(!Number.isFinite(value)||value<(key==='width'?20:8)||value>2200)return;stopPreview();setObjectDimension(selected,key,value);commit()};
 $('boxFontSize').oninput=()=>{if(!geometryText(selected))return;const value=+$('boxFontSize').value;if(value<12||value>360)return;stopPreview();selected.style.fontSize=value+'px';selected.style.height='auto';selected.style.overflow='visible';$('fontSize').value=value;commit()};
 $('boxRotation').oninput=()=>{if(!geometryObject(selected))return;const value=+$('boxRotation').value;if(!Number.isFinite(value)||value < -180||value > 180)return;stopPreview();selected.style.rotate=`${value}deg`;commit()};
 $('boxLineHeight').oninput=()=>{const value=+$('boxLineHeight').value;if(geometryText(selected)&&value>=.7&&value<=3){selected.style.lineHeight=value;selected.style.height='auto';selected.style.overflow='visible';commit()}};
 $('boxAlignment').onchange=()=>{if(geometryText(selected)){selected.style.textAlign=$('boxAlignment').value;commit()}};
 $('boxWrap').onchange=()=>{if(geometryText(selected)){selected.style.whiteSpace=$('boxWrap').value;selected.style.height='auto';selected.style.overflow='visible';commit()}};
 $('oneTextLine').onclick=oneTextLine;
 $('arrowStroke').oninput=()=>{const value=+$('arrowStroke').value;if(value<1||value>24)return;if(selected?.matches('svg.arrow')){selected.style.strokeWidth=value;selected.querySelectorAll('path,line,polyline').forEach(e=>e.style.strokeWidth=value);commit()}else if(selected?.matches('.line')){selected.style.height=value+'px';commit()}};
 syncGeometryControls();
};
const geometrySetup=setupUI;
setupUI=function(){geometrySetup();$('fontSize').max='360';const original=$('fontSize').oninput;$('fontSize').oninput=e=>{original(e);if($('boxFontSize')&&geometryText(selected))$('boxFontSize').value=e.target.value};window.addEventListener('resize',refreshResizeFrame)};
const geometryInspect=inspectDesign;
inspectDesign=function(){geometryInspect();const a=$('canvasViewport').querySelector('.slide'),scale=a.getBoundingClientRect().width/1080,warnings=[];
 a.querySelectorAll('[data-edit]').forEach(e=>{const css=getComputedStyle(e),r=e.getBoundingClientRect();if(e.matches('.hand')&&parseFloat(css.fontSize)<110)warnings.push('Handwritten emphasis is small: '+e.textContent.trim().slice(0,35));const range=document.createRange();range.selectNodeContents(e);const ink=range.getBoundingClientRect();if(ink.right>r.right+3*scale||ink.bottom>r.bottom+3*scale)warnings.push('Text overflows its box: '+e.textContent.trim().slice(0,35))});
 if(warnings.length)$('designCheck').textContent+=' • '+warnings.join(' • ');
};

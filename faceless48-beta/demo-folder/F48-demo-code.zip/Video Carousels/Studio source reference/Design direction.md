> **Current avatar workflow — October 15, 2026:** Dr. CK supplies avatar images. No avatar generation, regeneration, or appearance retouching by default. Routine work covers carousel design, proportional sizing, positioning and crop checks. Missing image: use a labeled placeholder. Specific image edits require an explicit request. Earlier generation guidance below is historical and does not authorize generating an avatar. See `Avatar production rules.md`.

# Dr. CiCi / C3 Global — current creative direction

User feedback from October 5 governs this revision:

- Modern luxe glam with editorial hierarchy, visible white/black/crimson marble, dimensional rose gold, luminous surfaces and soft atmospheric fades. Avoid flat fields and hard split transitions.
- Canonical crimson #C91B19 is the source hue. Richer perceived depth should come from neutral shadow and highlights, never a purple/burgundy substitution.
- Playfair Display and DM Sans remain core typefaces. Handwritten annotations are now explicitly requested; Handlee is an accent only.
- Preserve the current successful face, realistic tall plus-size proportions and approved wardrobe. Lookbook faces are not identity references.
- Seated posing should be composed, feminine and elegant: legs together/angled or crossed. Never slim the body to achieve the pose.
- Main new inspiration: annotated editorial teaching carousel with diagrams, tables, framework cards, curved arrows and handwritten notes. Borrow visual structure, not third-party technical claims or branding.
- Additional main cover reference: oversized serif emphasis, portrait, hand-drawn arrows and underlines. Additional grid reference: four independently replaceable portraits/options.
- Studio remains a personal testing prototype. Productization is explicitly out of current scope.


**Neckline default:** All necklines must be mid-level unless the user explicitly specifies otherwise. Follow approved lookbook outfits without deepening their necklines. Character sheets guide identity and proportions only. See `Avatar production rules.md`.


## October 8 direction
Rotate carousel families between posts, potentially two per week. Next candidate: Bold Point of View after Editorial Reflection. Dr. CiCi must appear on the first and last slides of new carousels. Marble is optional; when used, black and crimson textures should remain subdued behind legible text. Black overlays now 78–88%; crimson overlays 62–74%, applied consistently across families, project stages, and poster tiles.

### October 8 correction: red background
Supersedes the crimson dark-overlay instruction above. No red marble. Keep softened black and white marble. Red backgrounds use canonical crimson #C91B19 with a subtle velvet-inspired sheen and fine texture, without black overlays that shift the red to burgundy or brown. Applies across all template families, project stages and red poster tiles.

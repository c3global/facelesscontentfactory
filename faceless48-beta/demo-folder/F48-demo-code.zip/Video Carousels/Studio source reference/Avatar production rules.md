# Avatar workflow — user-supplied images only

Dr. CK's direct instruction, October 15, 2026, supersedes earlier avatar-generation workflows, identity-generation prompts, and automatic styling guidance.

- Dr. CK supplies the avatar images to use in carousels. Do not generate, regenerate, replace, or retouch her avatar by default.
- Do not alter face, expression, complexion, skin texture, makeup, hair, clothing, anatomy, body shape or proportions. Do not interpret layout feedback as permission to edit the person.
- Use the supplied image as an asset. Allowed carousel work: proportional whole-image resizing, positioning, layering, headroom, bottom-edge alignment, text separation, and profile-grid crop checks.
- Background removal, image retouching, restyling, or other changes to the supplied image require an explicit request for that specific edit. Never silently regenerate the person to accomplish them.
- If an avatar is missing or unsuitable, continue copy and non-avatar design with a clearly labeled placeholder. Ask for the intended user-supplied image when needed. Do not substitute a generated candidate or reuse an image without authorization.
- Preserve the original supplied file unchanged and keep layout derivatives separate.
- Review the cover and closing slide with the supplied avatar before final exports. Avatar placement approval is not approval to modify the underlying image.
- The generated October 15 floral/avatar retouch candidates are rejected. Do not reuse them as production assets, approved references, or identity anchors. Preserve them only as historical files; do not delete user files.

## Appearance checks for supplied assets

Report a mismatch rather than correcting it autonomously: no cleavage, middle neckline, naturally six feet tall without heels, heels at most two inches, full plus-size proportions with a long torso, realistic hair and skin. These are review criteria, not permission to generate or reshape her.

## Cover and closing variation — October 15

The cover and closing do not need matching framing. Vary proportional zoom, position and crop to make them distinct, using the supplied image without changing her appearance. Different user-supplied images may also be used when available. Keep crown headroom and intentional body crops; avoid duplicating the exact composition by default.

## Instagram output preference — October 15

Use Instagram 4:5 (1080 × 1350) going forward unless Dr. CK requests otherwise. Review cover headroom and layout in 4:5. White is not a mandatory cover background; choose the cover family/background for the story and user direction. Keep readability fades clear of the avatar’s face and hair.

## Family rotation — October 15

Alternate carousel families between successive posts. Avatar required on every cover. Vary portrait side, scale and framing, headline composition, and background; do not merely recolor the preceding carousel. Preserve the user-supplied pose rather than generating a new one. Current October 15 direction: Bold Point of View, replacing Editorial Reflection.

## Cutout framing and finish — October 15

Avoid floating upper-body cutouts with a hard horizontal endpoint against the same solid background. Anchor an intentional crop to a contrasting portrait panel, border or other designed boundary. A fine white or metallic penny-copper silhouette outline is authorized for this supplied avatar; keep it restrained and do not alter the person.

## Scoped request for brief two — October 15

Dr. CK explicitly requested a new seated editorial cover using the Culture Architect black outfit reference, the same hairstyle, curiosity/confusion in the expression, and an optional single app/mobile mockup. No books, coffee mug or generic desk clutter. This authorizes that cover candidate only; it does not revoke the standing user-supplied-avatar default for other work. Review likeness before further production.

## Brief two replacement — October 15

The seated generated cover likeness was rejected. Use the exact replacement cover supplied by Dr. CK (Oct19-COVER-USER-SUPPLIED.png). Do not regenerate or retouch this cover or reuse the rejected likeness. The scoped generation request is complete and does not authorize more attempts.

## Approved-avatar rotation — October 15

Dr. CK explicitly authorizes reuse and rotation of previously approved and used supplied avatar images for October 26, October 29 and November 2. Vary left/right placement and proportional framing; do not alter appearance or reuse rejected generated candidates. This authorization does not permit new avatar generation.

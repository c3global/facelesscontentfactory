# Cinematic Luxe icon wishlist

Keep the approved Studio icons in rotation. The requests below are potential additions, prioritized for reuse across the November briefs. Create the first group before the optional sets.

## First to create

| Icon | What it should communicate |
|---|---|
| Connected nodes | AI integration into an existing system |
| Tool or spark inside a task window | Actual AI use in a workflow |
| Split path with one detour | A workaround or alternate route |
| Checkpoint with a hand or eye | A human review or judgment call |
| Dashboard with a status dot | A status report that can be examined |
| Magnifying glass over a report | Verification and evidence |
| Warning triangle or flag | An exception, missing check, or risk |
| Clipboard with two check marks | Audit, readiness, or a set of questions |
| Speech bubble with a question mark | A question to ask the team |
| Loop of two arrows | Feedback and follow-through |
| Calendar or clock | Cadence, time, or a deadline |
| Two people side by side | A team, collaboration, or experience |

## Useful additions

- **Workflows and systems:** plug, link, branching decision diamond, gear, handoff, bottleneck, hourglass, approval stamp, lock, shield.
- **Evidence and reporting:** document stack, annotated document, bar chart, trend line, target, scorecard, progress meter, empty state, notification.
- **People and culture:** listening ear, paired speech bubbles, recognition badge, individual versus group, globe, bridge, open hand, reflection mirror.
- **Offers and follow-up:** envelope, follow-up arrow, inbox, CRM contact card, gift, storefront, cursor or tap, download.
- **Optional December overlays:** single star, snowflake, ribbon, gift bow, evergreen sprig, ornament. Keep them separate so neutral icons can be reused year-round.

## Asset format

One symbol per file with a transparent background, no embedded text, and generous padding. Prefer SVG for clean small-scale use, or high-resolution transparent PNG/WebP for rendered metallic objects. Start with a neutral, readable silhouette for each. Add copper rose gold for dark slides and reflective crimson for white marble where the same icon earns a second finish. Check that the symbol still reads at thumbnail size before adding surface detail.

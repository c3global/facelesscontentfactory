# Editorial Motion: current carousel direction

Dr. CK's latest direction, November 5, 2026. This supersedes the assumption that every video carousel must reuse the Carousel Studio visual treatment.

## Design

The supplied Instagram video carousels lead the new direction. Their clean, classy typography, spacing, restrained layouts, text effects, and explanatory graphics may be adapted closely as presentation methods. Use original C3 content and visuals. Do not force every piece into marble, velvet, or the prior Studio families. The imported Studio assets remain available when they serve a particular composition. Slate gray and clean neutral backgrounds are permitted. Typography resembling the references is acceptable to Dr. CK; Playfair Display and DM Sans remain available rather than compulsory for every treatment.

Crimson is #C91B19. The existing approved copper-metal reference is swatch 5: base #A9574A, highlight #F1B9A5. Make crimson read as crimson. Copper metallic rose gold requires reflective tonal variation and a controlled highlight, rather than flat peach lettering. Do not apply a burgundy wash to the whole composition.

## Motion

Build a reusable Faceless48 style with per-slide motion choices: short headline reveals, words or lines entering in meaningful groups, emphasis that changes with the explanation, arrows tracing a process, comparison states, and diagrams that advance. Text-sequence effects can stack with metallic shimmer clipped to the visible text. Keep reading holds after each reveal. Essential hook information is visible immediately. Decorative entrances alone do not satisfy this direction.

Each video slide is a separate file. The viewer controls the swipe, so every slide makes sense on its own and movement across cards must not depend on an uninterrupted shared clock. A continuous video is a separate export when requested.

## Dr. CiCi

This is Dr. CiCi's profile. Write in her first-person voice. Use her full name and proper title when identifying her. Do not narrate her in third person. An animated avatar is optional where it serves the idea. Dr. CK explicitly permits considering reuse of existing Clinic Notes footage and a cutout for that purpose. This does not authorize new avatar generation, restyling, or changes to her face/body. Preserve original footage and source images.

## Workflow

The intended experience is: supply the concept or copy, select a style, review the planned sequence and motion, receive ordered MP4 slides. The assistant handles layout and timing. A separate manual Carousel Studio editing session is not required.

The immediate rebuild is The Second Checklist. Use a visual demonstration of a completed AI review alongside a paper process that continues, with a traced connection to the approval that has not been completed. The first rejected draft is not the active style or approved copy.

The local Creator package's storyboard-before-render rule still applies. Produce a concrete storyboard with motion beats for review before final MP4 export. Do not claim still images demonstrate playback.

## Studio disposition

Do not delete, uninstall, stop services, or archive Carousel Studio without a clear final choice from Dr. CK. Her latest message expresses uncertainty about deleting it or keeping it as a future product. Preserve it and its saved projects. The asset copy into this project is complete and does not depend on deleting the original.

## Reference status

All four Instagram links remain in the first brief. Only the previously observed frame of De2-09Cjnyx has been visually inspected in this chat. On this turn, opening the existing reference tab was blocked by another extension UI, and a separate reference tab detached before inspection. No full pacing or motion review of all four is claimed. Dr. CK's explicit description of the desired clean layout and text animation is the current design instruction.

This is a direction document. It does not claim the video composition has already been rebuilt, played back, or approved.

## November 5: later visual feedback

Keep lowercase descenders and italic overhang fully visible throughout text reveals and at rest. Slide five reads “Ask what the document protects.” Add a light dark overlay to crimson velvet so text is legible while the texture and crimson remain visible. Slide four's headline font is pending Dr. CK's selection from Google Fonts; do not claim it is finalized. The reference screenshot featuring a central symbol, branching dotted lines, and three animated explanatory cards is a future layout direction, not a request to copy its words or claims.

Dr. CK is interested in Dr. CiCi appearing to travel from slide to slide. Instagram carousel cards run independently and advance when the viewer swipes, so coordinate the ending position of one clip and the beginning of the next; do not promise uninterrupted playback. A continuous-video version can show an uninterrupted movement. Source footage and a clean matte are required for an avatar implementation.

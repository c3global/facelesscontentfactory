Cinematic Luxe redesign — Experienced team and AI rollout

Six slides, 1080 x 1350, 30 fps, ten seconds per slide. Full headline and portrait visible from frame one. Portrait uses subtle placement motion; no generated facial or hand movement.

Scheduled date verified read-only in Marky: Wednesday November 11, 2026 at 5:53 p.m. America/New_York. Scheduled media have NOT been replaced.

Silent visual-review export. A DIFFERENT licensed track must be selected before final delivery; never repeat the first carousel music.

Frames: 1 cover / 2 map the task and detour / 3 experience and judgment / 4 real task, tool output, team review / 5 listen, change, share / 6 AIREADY invitation.

Source uses the existing Remotion 4 runtime. No new model or paid media generation.

# AI integration vs. adoption

Draft storyboard for the November 12 brief. Instagram CTA: AIREADY. Source: [Gallup, Organizational AI Adoption Jumps Six Points](https://www.gallup.com/workplace/712736/organizational-adoption-jumps-six-points.aspx). Use the same May 2026 survey for both measures, with U.S. employees identified on screen. These are two separately reported measures.

| Slide | On-screen headline | Visual and motion |
|---|---|---|
| 1 | Your team has AI. How often do they use it? | Fully composed white-marble cover with Dr. CiCi's presenting portrait and two copper-edged cards labeled Integration and Use. Keep the number reveal for slide 2. |
| 2 | 30% used AI a few times a week or more. | Reveal a copper counter and a horizontal bar labeled U.S. employees. Keep May 2026 and Gallup visible beside the measure. |
| 3 | 47% said their organization had integrated AI tools. | Reveal a separate bar using the same scale. Label it Reported organizational integration. No funnel or arrows between the two percentages. |
| 4 | Where does AI fit into the work? | Build a task map with two branches: Where the tool helps and Where the team uses another route. Use the approved Studio info and speech-bubble objects where legible. |
| 5 | Ask for one example of each. | Reveal two prompts in order: “When did AI help you this week?” and “When did you choose another way to do it?” |
| 6 | Ready to see what your team needs? | On crimson velvet, reveal Dr. CiCi’s larger notebook portrait beside the AIREADY keyword. Supporting copy: “Comment AIREADY and I’ll send you the AI Advantage Audit.” |

Use the approved Studio library and Dr. CiCi portraits. Cover elements visible from the first frame. Keep interior headlines visible while their visual explanations build. Use a distinct track from the Cinematic Carousels folder. This storyboard has not been rendered or scheduled.

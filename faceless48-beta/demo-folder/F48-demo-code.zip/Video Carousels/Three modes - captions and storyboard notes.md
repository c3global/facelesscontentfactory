# Three video-carousel directions: draft captions and notes

For review. Today's approved carousel remains unchanged. These are storyboards, not finished videos. Each proposed design uses its mode throughout; the user may request a mix or a different pairing. Each written caption includes one activity and one primary CTA. TikTok CTA replaces the Instagram/Facebook comment CTA; do not use both in a single post. Confirm the keyword response is operational before publishing. No posts have been created or scheduled.

## 1. Experienced team members: black mode

Handoff template for the carousel hook: Hooks & Caption Starters, page 3, #8. The Veterans Day placement in the handoff is a proposed date, not a scheduled post. Avoid implying that long-serving team members are necessarily veterans, or treating workplace experience as military service.

**Draft caption:**

You’re getting ready to introduce an AI tool to your team. Before the rollout meeting ends, look around the room. Who understands the exceptions that make the work harder than it looks on paper?

People who have done the work for years can tell you where a simple process gets complicated. Their experience can help your team test the tool against the work people actually do, before frustration becomes part of the rollout.

At your next planning meeting, ask one person who does the work to walk you through a recent task from beginning to end. Listen for the step that takes judgment.

Comment AIREADY and let's see whether your organization is actually ready.

**TikTok CTA:** DM me AIREADY and let's see whether your organization is actually ready.

**Destination:** AI Advantage Audit, https://www.c3global.co/aiaudit.

## 2. Integration and adoption: white marble mode

Handoff template for the carousel hook: Hooks & Caption Starters, page 3, #32. Use Gallup May 2026 survey figures with the date and U.S. employee population. The figures measure two different things and must not be described as the same workers or a 17-point conversion funnel. Gallup's series includes newer measurements, so recheck before scheduling.

**Draft caption:**

Your organization has invested in AI. You may even have a rollout plan. But if you lead a team, there’s another question to bring into your next meeting: where does the tool actually fit into the work?

In May 2026, Gallup reported that 47% of U.S. employees said their organization had integrated AI tools, while 30% said they used AI at work a few times a week or more. Those numbers describe different things: an organization’s integration and an employee’s frequency of use.

A tool can be available without becoming part of someone’s routine. Knowing where that happens gives you a better starting point for a conversation about readiness.

At your next team meeting, ask people to name one task where the tool helps and one where they still choose another way to work.

Comment AIREADY and let's see whether your organization is actually ready.

**TikTok CTA:** DM me AIREADY and let's see whether your organization is actually ready.

**Source:** Gallup, Global Indicator: Artificial Intelligence, May 2026 figures, https://www.gallup.com/699797/indicator-artificial-intelligence.aspx. **Destination:** https://www.c3global.co/aiaudit.

## 3. Workarounds and resistance: crimson velvet mode

Handoff template: Authority Builders #25, the Stop Doing list. This draft does not use an unverified percentage or present a fictional client as real. The connection to Patient File #004 informs the diagnosis; its working script has not been locked.

**Draft caption:**

Your team has a new AI tool, but people keep finding another way to get the job done. As the person leading the rollout, you may feel pressure to call that resistance and move on.

Before your next adoption review, follow one task from the point where someone opens the tool to the point where the work gets finished. A workaround can show you where a step doesn’t fit, where an answer is hard to find, or where someone needs more clarity. It can have other causes too, so ask the people doing the work before deciding what it means.

Try asking: “What are you able to do with your current approach that the tool doesn’t help you do yet?”

Comment SHIFT and I’ll send you the readiness index.

**TikTok CTA:** DM me SHIFT and I’ll send you the readiness index.

**Destination:** Shift Index, https://www.c3global.co/shiftindex.

## Source and production checks

- Notion: Q4 Daily Campaign: November Plan, https://app.notion.com/p/3ffd063485968125834ac6f1692f5d83 (the plan identifies unresolved schedule conflicts).
- Notion: Copy Rules, https://app.notion.com/p/3edd06348596813f9a3ae03e45f69da4.
- Notion: CTA & Keyword System, https://app.notion.com/p/3d8d0634859681ec9386ea2ea2d9670e.
- Notion: The Rejection, Patient File #004, https://app.notion.com/p/3f2d0634859681d6b3fed524e4c77ce7 (working, awaiting script lock).
- The specified carousel hook templates come from the supplied eight-concept handoff. These captions are new drafts; their caption-opening template attribution still needs verification against the full Approved Copy Library before production.

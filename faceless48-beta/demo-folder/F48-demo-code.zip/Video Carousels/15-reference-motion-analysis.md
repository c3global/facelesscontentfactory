# Video carousel reference review

Source: Dr. CK's 9:47 local screen recording and transcript, November 5. Reviewed the recording from beginning to end using frames sampled approximately every three seconds, plus the accompanying transcript. The recording itself includes pauses, page transitions, replays and narration, so timestamps below refer to recording time, not original post dates. Fine motion between sampled frames was not continuously observed. User narration describes additional effects. Reference material is inspiration for original C3 content; no third-party statistics or copy are transferred as C3 facts.

## 1. Videos and dashboards, about 00:00–02:17

- The cover places two illustrative screens in a scene, with a dashboard graph and video chart. This is a specific visual demonstration, not a generic icon.
- The next slide collects questions in separate pills leading toward a central mark. The following slide branches one central idea into two compact cards.
- An instruction slide combines a mock interface with a three-step path. Another slide uses a quotation panel. Two later slides pair a prompt with an example output: one includes a map, the other a dashboard.
- The end card has an oversized rounded keyword pill, clean supporting text and a simple central motif. User narration describes animated lines, highlights, dashboard movement and an approximately ten-second loop on slides. Screenshot analysis alone cannot verify each subsecond detail.

## 2. Why leads go cold, about 02:20–05:43

- The cover shows three message-channel mockups. The recorded progression shows their bright messages changing to muted or gray states: the change itself expresses fading engagement.
- A list of unanswered messages builds within an interface. Four tiles build on another slide; a horizontal comparison graph grows into a small table of results. A two-column set of causes appears in sequence.
- Later slides show annotated conversation text, a practical example, a process visual and an oversized keyword CTA. The shapes and visual density change with the point, while typography and palette remain recognizable.
- Dr. CK points out card flips and reflective details in her narration. Do not assume a static frame alone proves their exact timing.

## 3. Fix your hook, about 05:45–09:22

- The cover uses a cluster of vertical screens and social-style elements. A demonstration slide combines a countdown, text and a stepped graph.
- Other layouts include three compact rule cards, a hub connecting them, a comparative bar chart, a six-person list, and a two-by-two grid. The recorded frames show charts and cards appearing in stages.
- One slide compares examples in stacked rows. Another uses an interface field and a branching diagram, with intermediate states shown before it settles. Dr. CK emphasizes balanced use of space and the amount that happens within one slide.
- A simple final CTA pill gives the eye one clear action after the more involved middle slides.

## C3 application

- Each slide needs a specific visual job, clear visual hierarchy, and meaningful motion that reveals an explanation. Choose a chart for verified numerical comparisons, a process map for a workflow, a split view for before/after, a numbered path for instructions, or a contextual interface for a realistic demonstration. Do not add irrelevant stock symbols or decorative lines.
- Keep bold centered type and copper rose-gold metallic italic accents. Preserve legibility and safe margins. Use black/charcoal, approved white marble and crimson velvet in a purposeful mix; crimson can recur and may close a carousel.
- Use C3's supplied assets where they fit. Dr. CiCi is optional and may enter after two or three seconds. Preserve her appearance and use only approved footage; a suitable still is acceptable.
- Text and diagram elements should build in logical beats and hold for reading. Loop only where it makes sense, not by reversing human movement. Each video slide must work independently.
- Closing: explore an oversized holographic CTA pill with the correct keyword and meaningful follow-up. Keep C3 Global footer and bio.c3global.co centered.
- Copy must follow the Notion Copy Rules, plain English, verified sources and CTA system. The Gallup organization-integration and employee-use numbers are distinct measures, not a single tracked cohort.
- Retain the approved Second Checklist; rebuild the next carousel's storyboard as a separate version and show stills before the first video render under the Faceless48 video-production skill. Do not publish or schedule anything.

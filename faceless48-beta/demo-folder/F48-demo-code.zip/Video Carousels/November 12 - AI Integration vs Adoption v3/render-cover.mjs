import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill} from '@remotion/renderer';
import {mkdir} from 'node:fs/promises';
const browserExecutable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const serveUrl=await bundle({entryPoint:process.cwd()+'/entry.tsx',publicDir:process.cwd()+'/public'});
const composition=await selectComposition({serveUrl,id:'Cover',browserExecutable});
await mkdir('out',{recursive:true});
await renderStill({serveUrl,composition,browserExecutable,frame:30,output:'out/Cover motion.png'});
await renderMedia({serveUrl,composition,browserExecutable,outputLocation:'out/Cover motion.mp4',codec:'h264',concurrency:1});

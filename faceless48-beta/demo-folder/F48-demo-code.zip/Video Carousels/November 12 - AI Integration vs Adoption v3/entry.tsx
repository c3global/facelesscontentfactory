import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Luxe} from './Luxe';
registerRoot(() => <><Composition id="Integration" component={Luxe} durationInFrames={1800} fps={30} width={1080} height={1350}/><Composition id="Cover" component={Luxe} defaultProps={{fixedSlide:1}} durationInFrames={213} fps={30} width={1080} height={1350}/><Composition id="Close" component={Luxe} defaultProps={{fixedSlide:6}} durationInFrames={300} fps={30} width={1080} height={1350}/></>);

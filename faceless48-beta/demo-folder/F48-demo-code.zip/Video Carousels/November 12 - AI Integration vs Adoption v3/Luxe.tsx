import React from 'react';
import {AbsoluteFill,Img,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import {logoWhite,logoBlack} from './logos';
const C='#F1B9A5',M='#A9574A',R='#C91B19',B='Manrope',S='Playfair Display';
const p=(t:number,a=0,d=1)=>Math.max(0,Math.min(1,(t-a)/d));
function reveal(time: number, start: number, distance = 18): React.CSSProperties {
  const progress = p(time, start, .42);
  const eased = 1 - (1 - progress) ** 3;
  return {opacity: progress, transform: `translateY(${distance * (1 - eased)}px)`};
}
let loaded=false;function fonts(){if(loaded)return;loaded=true;const h=delayRender();Promise.all([['Manrope','manrope-latin-800-normal.woff2','normal','800'],['Playfair Display','PlayfairDisplay-Italic.ttf','italic','100 900'],['DM Sans','DMSans.ttf','normal','100 900']].map(async([name,f,style,weight])=>{const face=await new FontFace(name,`url(${staticFile('brand/carousel-studio/'+f)})`,{style,weight}).load();document.fonts.add(face)})).then(()=>continueRender(h)).catch(cancelRender)}
const Icon=({kind='doc',size=55,color=C}:{kind?:string;size?:number;color?:string})=><svg width={size} height={size} viewBox="0 0 64 64" fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">{kind==='check'?<><circle cx="32" cy="32" r="25"/><path d="m19 32 9 9 18-20"/></>:kind==='people'?<><circle cx="32" cy="18" r="10"/><path d="M13 54v-7c0-22 38-22 38 0v7M8 20a8 8 0 0 0 0 16m48-16a8 8 0 0 1 0 16"/></>:kind==='eye'?<><path d="M4 32s11-19 28-19 28 19 28 19-11 19-28 19S4 32 4 32Z"/><circle cx="32" cy="32" r="9"/></>:kind==='chat'?<><path d="M9 8h46v34H28L13 55V42H9Z"/><path d="M19 21h26M19 30h18"/></>:<><path d="M15 5h24l12 12v42H15Z M39 5v14h12 M23 30h20M23 39h20M23 48h13"/></>}</svg>;
const Metal:React.FC<{children:React.ReactNode;t:number;size?:number;onMarble?:boolean}>=({children,t,size=83,onMarble=false})=><span style={{fontFamily:S,fontStyle:'italic',fontWeight:600,fontSize:size,lineHeight:1.25,paddingBottom:15,display:'inline-block',backgroundImage:onMarble?'linear-gradient(110deg,#760C13 4%,#A71921 24%,#D54040 32%,#AE1822 42%,#780D15 64%,#B81E29 91%)':`linear-gradient(110deg,${M},${C} 25%,#FFF8EF 33%,${C} 40%,${M} 70%,${C})`,backgroundSize:'230% 100%',backgroundPosition:`${100-(t%5)/5*220}% 0`,backgroundClip:'text',WebkitBackgroundClip:'text',color:'transparent'}}>{children}</span>;
const Panel:React.FC<{children?:React.ReactNode;style?:React.CSSProperties;light?:boolean}>=({children,style,light})=><div style={{position:'absolute',zIndex:2,borderRadius:25,border:`1.5px solid ${light?'#B7827066':'#F1B9A56B'}`,background:light?'linear-gradient(145deg,#FFFFFFF5,#FFFFFFA8)':'linear-gradient(145deg,rgba(241,185,165,.15),rgba(169,87,74,.10) 55%,rgba(241,185,165,.06))',boxShadow:light?'inset 0 2px 1px #fff,0 14px 30px #35231A14':'inset 0 2px 1px #FFE4D077,inset 0 -1px 2px #A9574A77,0 14px 35px #0004',boxSizing:'border-box',...style}}>{children}</div>;
const Mini=({children,style}:any)=><div style={{fontSize:20,letterSpacing:2,fontWeight:800,...style}}>{children}</div>;
const Line=({d,t,a=0,color=C}:{d:string;t:number;a?:number;color?:string})=><path d={d} stroke={color} strokeWidth="4" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p(t,a,1.4)} opacity={t>a?1:0} strokeLinecap="round" strokeLinejoin="round"/>;
const headlines = [
  ['Your team has AI.', 'How often do they use it?'],
  ['How often is AI used', 'in the work itself?'],
  ['How many say AI is', 'already integrated?'],
  ['Where does AI fit', 'into the work?'],
  ['Ask for one example', 'of each.'],
  ['Ready to see what', 'your team needs?'],
];
const labels = ['AI INTEGRATION VS. ADOPTION','01 / FREQUENCY OF USE','02 / ORGANIZATIONAL INTEGRATION','03 / FOLLOW THE WORK','04 / ASK THE TEAM','THE AI ADVANTAGE AUDIT'];
const Metric = ({t,percent,label,light}:{t:number;percent:number;label:string;light:boolean}) => {
  const fill=p(t,.75,1.65);
  const number=Math.round(percent*(1-(1-fill)**3));
  return <Panel light={light} style={{left:68,top:445,width:944,height:600,padding:48,...reveal(t,.24)}}>
    <Mini style={{color:light?'#A71921':C}}>GALLUP / MAY 2026</Mini>
    <div style={{fontVariantNumeric:'tabular-nums',fontSize:175,fontWeight:800,lineHeight:1.12,marginTop:34,color:light?'#A71921':C}}>{number}%</div>
    <div style={{fontSize:39,lineHeight:1.25,maxWidth:780,marginTop:16}}>{label}</div>
    <div style={{height:23,marginTop:55,borderRadius:12,background:light?'#A9574A28':'#FFFFFF20',overflow:'hidden'}}>
      <div style={{height:'100%',width:`${number}%`,background:light?'linear-gradient(90deg,#7A0D16,#C91B19,#D34242)':`linear-gradient(90deg,${R},${C})`,borderRadius:12}}/>
    </div>
    <div style={{display:'flex',justifyContent:'space-between',marginTop:12,fontSize:20,opacity:.8}}><span>0%</span><span>100%</span></div>
  </Panel>;
};
export const Luxe: React.FC<{fixedSlide?: number}> = ({fixedSlide}) => {
  fonts();
  const frame=useCurrentFrame();
  const slide=fixedSlide??Math.floor(frame/300)+1;
  const t=(frame%300)/30;
  const light=slide===3||slide===5;
  const red=slide===6;
  const ink=light?'#17191D':'#FFFFFF';
  const muted=light?'#53535C':'#D5C4C4';
  const upperLightX=487+158*(1-Math.cos(t*Math.PI/1.48))/2;
  const lowerLightX=487+146*(1-Math.cos((t+.62)*Math.PI/1.68))/2;
  const upperLightY=577+Math.min(40,Math.max(0,upperLightX-519));
  const lowerLightY=815-Math.min(51,Math.max(0,lowerLightX-527));
  const color=light?'#A71921':C;
  return <AbsoluteFill style={{background:light?'#F5F3F0':red?R:'#101113',color:ink,fontFamily:B,overflow:'hidden'}}>
    {light&&<AbsoluteFill style={{backgroundImage:`url(${staticFile('brand/carousel-studio/marble-materials.jpg')})`,backgroundSize:'300% 100%',backgroundPosition:'left',opacity:.48}}/>}
    {red&&<><Img src={staticFile('brand/carousel-studio/crimson-velvet.jpg')} style={{width:'100%',height:'100%',objectFit:'cover'}}/><AbsoluteFill style={{background:'linear-gradient(145deg,#13000044,#0000005C)'}}/></>}
    {!light&&!red&&<AbsoluteFill style={{backgroundImage:'radial-gradient(#D598804D .9px,transparent 1px),radial-gradient(ellipse at 60% 65%,#A9574A25,transparent 65%)',backgroundSize:'22px 22px,100% 100%'}}/>}
    <div style={{position:'absolute',left:66,right:66,top:46,display:'flex',justifyContent:'space-between',fontSize:18,letterSpacing:1.5,color:muted}}><span>DR. CICI / C3 GLOBAL</span><span>0{slide} / 06</span></div>
    <div style={{position:'absolute',top:132,left:55,right:55,textAlign:'center'}}>
      <Mini style={{color:muted,fontSize:18,marginBottom:23}}>{labels[slide-1]}</Mini>
      <div style={{fontSize:80,fontWeight:800,lineHeight:1.17,letterSpacing:-2.5}}>{headlines[slide-1][0]}</div>
      <Metal t={t} size={slide===1?76:86} onMarble={light}>{headlines[slide-1][1]}</Metal>
    </div>
    {slide===1&&<>
      <svg width="1080" height="1350" style={{position:'absolute',inset:0,pointerEvents:'none'}} aria-hidden>
        <defs><linearGradient id="scan-trace"><stop stopColor="#A9574A00"/><stop offset=".6" stopColor="#F1B9A5"/><stop offset="1" stopColor="#F1B9A500"/></linearGradient></defs>
        <path d="M483 577h36l40 40h111 M483 815h44l51-51h111" stroke="#F1B9A57C" strokeWidth="2" fill="none"/>
        <path d="M480 437h86m-86 0v64m545-64h-86m86 0v64" stroke="#F1B9A571" strokeWidth="2" fill="none"/>
        <ellipse cx="810" cy="864" rx="315" ry="385" fill="none" stroke="#A9574A3B" strokeWidth="2" strokeDasharray="4 12"/>
        {[[110,415],[242,452],[423,404],[539,421],[619,488],[484,1035],[352,1118],[242,1184],[99,1163],[72,967],[441,959],[573,538],[979,410]].map(([x,y],i)=><circle key={i} cx={x} cy={y} r={1.5+1.4*Math.pow((1+Math.sin(t*2.3+i*1.8))/2,3)} fill="#F1B9A5" opacity={.18+.52*Math.pow((1+Math.sin(t*2.3+i*1.8))/2,3)}/>)}
        <circle cx={upperLightX} cy={upperLightY} r="13" fill="#F1B9A5" opacity=".17"/>
        <circle cx={upperLightX} cy={upperLightY} r="5.5" fill="#FFE6D9"/>
        <circle cx={lowerLightX} cy={lowerLightY} r="13" fill="#F1B9A5" opacity=".17"/>
        <circle cx={lowerLightX} cy={lowerLightY} r="5.5" fill="#FFE6D9"/>
        <path d={`M486 ${455+250*p(t,.45,3.2)}h533`} stroke="url(#scan-trace)" strokeWidth="2" opacity={.34*Math.sin(Math.PI*p(t,.45,3.2))}/>
      </svg>
      <Img src={staticFile('portraits/dr-cici-presenting-left.png')} style={{position:'absolute',right:-125,bottom:-28,width:752,height:'auto',transform:`translateX(${-9*Math.sin(Math.min(t,4)*Math.PI/4)}px)`}}/>
      {[['01 / INTEGRATION','Where AI is available.'],['02 / USE','How often people turn to it.']].map(([label,copy],i)=><Panel key={label} style={{left:65,top:480+i*238,width:418,height:194,padding:30,background:'linear-gradient(140deg,#2C2022F5,#17171BEF)'}}>
        <Mini style={{color:C}}>{label}</Mini><div style={{fontSize:36,lineHeight:1.2,marginTop:23}}>{copy}</div>
      </Panel>)}
      <div style={{position:'absolute',left:70,top:1007,width:430,fontSize:29,color:C}}>Two questions for your rollout.</div>
    </>}
    {slide===2&&<Metric t={t} percent={30} light={false} label="of U.S. employees used AI at work a few times a week or more."/>}
    {slide===3&&<Metric t={t} percent={47} light label="of U.S. employees said their organization had integrated AI tools."/>}
    {(slide===2||slide===3)&&<div style={{position:'absolute',top:1106,left:72,right:72,textAlign:'center',fontSize:29,color:muted,...reveal(t,2.5)}}>{slide===2?'This measures how often people use AI.':'This measures reported integration.'}</div>}
    {slide===4&&<>
      <Panel style={{left:257,top:426,width:566,height:153,padding:24,display:'flex',gap:23,alignItems:'center',...reveal(t,.22)}}><Img src={staticFile('objects/info.webp')} style={{width:92,height:92,objectFit:'contain'}}/><div><Mini style={{color:C}}>START HERE</Mini><div style={{fontSize:37,marginTop:8}}>Pick one real task.</div></div></Panel>
      <svg width="1080" height="1350" style={{position:'absolute',inset:0,pointerEvents:'none'}}><Line d="M540 579v57H292v68 M540 636h248v68" t={t} a={.75}/></svg>
      {[['TOOL HELPS','Where does the team reach for AI?'],['ANOTHER ROUTE','Where does the team take a different path?']].map(([label,copy],i)=><Panel key={label} style={{left:63+i*491,top:710,width:463,height:365,padding:33,...reveal(t,1.5+i*.75)}}><Mini style={{color:C}}>0{i+1} / {label}</Mini><div style={{fontSize:43,lineHeight:1.23,marginTop:34}}>{copy}</div></Panel>)}
    </>}
    {slide===5&&[
      ['WHEN AI HELPED','When did AI help you this week?'],
      ['WHEN THE TEAM CHOSE ANOTHER ROUTE','When did you choose another way to do it?'],
    ].map(([label,copy],i)=><Panel light key={label} style={{left:70,top:448+i*313,width:940,height:253,padding:34,display:'flex',gap:28,alignItems:'center',...reveal(t,.4+i*1.25)}}>
      <Img src={staticFile('objects/bubble-rose.webp')} style={{width:112,height:112,objectFit:'contain'}}/>
      <div><Mini style={{color}}>{label}</Mini><div style={{fontSize:44,lineHeight:1.22,marginTop:20}}>“{copy}”</div></div>
    </Panel>)}
    {slide===6&&<>
      <Panel style={{left:69,top:432,width:942,height:132,padding:25,display:'flex',alignItems:'center',gap:22,...reveal(t,.28)}}><Icon kind="doc"/><div style={{fontSize:32}}>Find your next step with the AI Advantage Audit.</div></Panel>
      <Img src={staticFile('portraits/dr-cici-notebook-white.png')} style={{position:'absolute',right:-32,bottom:-4,width:565,height:'auto',opacity:p(t,.85,.55),transform:`translateX(${28*(1-p(t,.85,.65))}px)`}}/>
      <div style={{position:'absolute',left:59,top:673,width:520,textAlign:'center'}}>
        <div style={{fontSize:34,...reveal(t,1.03)}}>Comment</div>
        <div style={reveal(t,1.28)}><Metal t={t} size={109}>AIREADY</Metal></div>
        <svg width="500" height="52" viewBox="0 0 760 70" style={{display:'block',margin:'-12px auto 20px'}}><Line d="M15 40Q110 10 230 35T470 35T745 23" t={t} a={1.65}/></svg>
        <div style={{fontSize:31,lineHeight:1.4,...reveal(t,2.55)}}>and I’ll send you<br/>the AI Advantage Audit.</div>
      </div>
    </>}
    <Img src={light?logoBlack:logoWhite} style={{position:'absolute',left:65,bottom:42,width:108,height:53,objectFit:'contain'}}/>
    <div style={{position:'absolute',bottom:54,left:slide===1||slide===6?205:250,right:slide===1||slide===6?535:250,textAlign:'center',fontSize:22,color:muted}}>bio.c3global.co</div>
    <div style={{position:'absolute',bottom:48,right:66,fontSize:32,color,background:slide===1||slide===6?'#101113D0':undefined,borderRadius:slide===1||slide===6?24:undefined,padding:slide===1||slide===6?'1px 11px':undefined}}>↗</div>
  </AbsoluteFill>;
};

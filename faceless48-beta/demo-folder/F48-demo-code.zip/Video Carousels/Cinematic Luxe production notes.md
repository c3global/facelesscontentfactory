# Cinematic Luxe production preferences

Use approved Studio assets and icons first. Use approved Dr. CiCi portraits on the cover and closing slide. The cover opens fully composed, with subtle portrait motion. The larger closing portrait animates in alongside the call to action. On interior slides, the headline is visible from frame one, with staged graphic reveals below it.

Use the licensed [Cinematic Carousels folder](https://drive.google.com/drive/folders/1UUXGRLYUX0oDt0XCMJffSWjrj0uTTUYb) as the default music source. Log artist, title and version by carousel to avoid repeating songs, including alternate mixes. Star Chariot by Clejan is assigned to Experienced Team. For December, prioritize holiday arrangements in the same style, especially closer to Christmas.

## Cover and contrast rules

Always start in dark mode. Aim for a tech-forward editorial cover with copper-edged interface cards, fine connector lines, or subtle motion that supports the idea. Scale Dr. CiCi up and anchor her portrait to the bottom or side edge. Align presenting gestures with an on-slide element or a deliberate continuation across the swipe.

Use reflective metallic red for accented type and emphasis on white marble. Keep the brightest point of the shimmer a saturated red so the text remains readable. Use copper metallic rose gold on dark slides. If a portrait appears on a light interior slide, favor wardrobe with clear contrast against the marble.

On closing slides, anchor Dr. CiCi to the bottom or side edge. If a portrait must end within the frame, the fade must reach full transparency before the source image's lower edge. Keep the footer clear of the portrait.

Music in review: Set Off (instrumental) by Clejan is assigned to November 12, AI Integration vs. Adoption, from the Cinematic Carousels folder.

Keep the opening strings on slide one and time the first beat drop to the first frame of slide two. For November 12, Set Off has a drop at about 7.1 seconds. The approved visual review with this timing uses a 7.1-second cover followed by five 10-second slides. Keep the track at its original tempo.

Dr. CK supplied the expanded C3G Icons library under `C3 Global/**C3G Graphics/C3G Icons`. For Workarounds, start with Metallic Copper Detour Route Icon-2 and Rose-Gold AI Task Workflow Window. For Green Status Report, start with Rose-Gold Analytics Dashboard Monitor and Rose-Gold Report Magnifying Glass. Some files have backgrounds baked into the artwork. Use those in a panel, or check for a transparent alternative before placing directly over marble or dark backgrounds.

Use visible green whenever the content calls for green. For Green Status Report, make the dashboard status light clearly green.

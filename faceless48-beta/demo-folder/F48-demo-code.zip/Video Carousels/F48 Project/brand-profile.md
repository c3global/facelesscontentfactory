# C3 Global video carousels

Use crimson #C91B19, black #000000, white #FFFFFF, copper #A9574A and highlight #F1B9A5. Use bundled DM Sans and Playfair Display. This project is for individually swipeable motion slides. Default canvas 1080 by 1350, 30 fps. Each slide must make sense muted. Use original animated evidence graphics and purposeful movement. No invented client stories or results. Patient File references must be identified as that series. One primary ask: SHIFT, routed to https://www.c3global.co/shiftindex.

The Second Checklist is the first storyboard, intended for November 5, 2026. Full source references and uncertainty are in ../01-second-checklist-editor-brief.md. Approval of storyboard precedes any MP4 render. Never schedule or publish from this project.

## November 5 correction, current direction

The first carousel storyboard was rejected. Follow `../03-studio-asset-handoff.md`. Use imported Studio materials under public/brand/carousel-studio, preserve visible crimson #C91B19 and copper metallic rose gold, and use varied approved Studio compositions. Write from Dr. CiCi's first-person perspective on her profile. Never call her CiCi alone in identification or narrate her in third person. Static storyboard images cannot demonstrate motion. Show meaningful animated explanations, rather than relying on text cards and decorative entrances.

## Latest direction: reference-led Editorial Motion

Read `../04-editorial-motion-direction.md` before the rebuild. Dr. CK permits close adaptation of the references' clean presentation, typography and text effects with her crimson and copper metallic rose gold. Studio materials are an optional asset library, not mandatory backgrounds. First-person voice on Dr. CiCi's profile. Existing Clinic Notes footage may be considered for an animated cutout when it serves the idea. Do not delete Studio: the user has not made a final decision. The initial seven-slide implementation remains rejected and must not be rendered as final.

## Approved direction from Dr. CK, November 5

The clean editorial motion direction is a preferred C3 Global video-carousel style: black dotted background, centered bold headlines, italic copper metallic type, handwritten notes, crisp visual explanations, translucent beveled cards, crimson velvet and white marble where suitable. Use copper rose-gold accent strokes that animate and glint sparingly. Keep the bio.c3global.co footer centered mathematically. Use the 4:5 layout as the current default, and verify destination cropping and format on each actual publishing workflow. Dr. CK prefers the current typefaces. Preserve the real Dr. CiCi appearance in supplied footage; obtain explicit instructions for any identity correction or alteration.

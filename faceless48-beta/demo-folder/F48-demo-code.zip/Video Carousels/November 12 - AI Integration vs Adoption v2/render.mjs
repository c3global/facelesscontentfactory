import {bundle} from '@remotion/bundler';
import {selectComposition,renderMedia,renderStill} from '@remotion/renderer';
import {mkdir} from 'node:fs/promises';
const browserExecutable='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const serveUrl=await bundle({entryPoint:process.cwd()+'/entry.tsx',publicDir:process.cwd()+'/public'});
const composition=await selectComposition({serveUrl,id:'Integration',browserExecutable});
await mkdir('out',{recursive:true});
for(let index=0;index<6;index++){
  await renderStill({serveUrl,composition,browserExecutable,frame:index*300+(index===0?0:150),output:'out/slide-'+(index+1)+'.png'});
}
let last=-1;
await renderMedia({serveUrl,composition,browserExecutable,outputLocation:'out/Thursday visual preview.mp4',codec:'h264',concurrency:1,onProgress:({progress})=>{const step=Math.floor(progress*10);if(step!==last){last=step;console.log('Render '+step*10+'%');}}});

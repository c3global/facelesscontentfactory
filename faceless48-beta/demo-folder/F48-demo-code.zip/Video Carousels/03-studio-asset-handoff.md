# Carousel Studio assets are accessible

The original local project was found at `/Users/c3global/Documents/ChatGPT/C3G Content/Carousel Studio`. The shared chat was read at https://chatgpt.com/s/cx_6aec8c42f0d481918b32bc10fa0d48b5.

The exact crimson velvet and marble textures, core fonts, handwritten font library, logos, and 17 brand objects have been copied unchanged into the Faceless48 customer project's `public/brand/carousel-studio/` folder. SHA-256 matches are recorded in `Studio asset import manifest.json`.

Original layout definitions, metal/background CSS, motion source, and production rules are copied to `Studio source reference/`. These files are a reference library; the Faceless48 composition has not yet been rebuilt with them. The installed Studio and its saved projects were not modified.

## Latest user direction, November 5

- The first storyboard draft is rejected. Do not render its seven MP4s.
- Crimson red #C91B19 must remain visibly crimson. Do not shade the whole slide into burgundy, brown, or wine.
- Metallic accents are copper metallic rose gold with a real reflective finish. Preserve the approved material treatment; a flat pale text color is insufficient.
- Reuse existing Studio backgrounds and distinct layouts. Slate gray is permitted.
- Latest Studio source specifies crimson velvet for red slides, softened black marble, and white marble. Red marble is an earlier superseded direction.
- Dr. CiCi is Dr. CK's AI avatar. This is her profile. Use her first-person voice; do not narrate her in third person. Use her full name and proper title when identifying her.
- Visual explanation needs meaningful motion and specific graphics. A line tracing the duplicate workflow, a required approval blocking the old process, a comparison that changes state, and a drawn annotation can carry the reasoning. Fade-ins and decorative drifting alone do not satisfy the request.
- The next storyboard should demonstrate distinct compositions using the actual assets. A timed motion breakdown should show what changes and why on each slide. Final motion review must include playback, because stills cannot demonstrate animation.

## What the user needs to send

Nothing is needed to transfer the local source asset library; it is already accessible and copied. If the newest personal edits exist only inside the MacBook Air's browser, open that edited project there, choose **Download project**, and bring the `.c3g.json` file into this workspace or attach it. That preserves text, positions, image choices, and animation settings. **Save edited studio** provides a portable HTML backup of the complete library and included projects when a complete browser copy is needed.

The shared chat supplies design history but does not synchronize browser-only project changes. PNGs and screenshots flatten the editable layers and are secondary references rather than the best source for migration.
